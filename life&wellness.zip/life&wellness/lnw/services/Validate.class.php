<?php

	class Validate{
		public function validateString($string, $mode = '', $minlength = '', $maxlength = '', $required = 0){
			if($required AND !strlen($string)){
				return 0;
			}else{
				if((strlen($maxlength)) AND (strlen($minlength)) AND (strlen($string) >= $minlength) AND (strlen($string) <= $maxlength))
					$result1 = 1;
				else if((strlen($minlength)) AND !strlen($maxlength) AND (strlen($string) >= $minlength))
					$result1 = 1;
				else if((strlen($maxlength)) AND !strlen($minlength) AND (strlen($string) <= $maxlength))
					$result1 = 1;
				else if((!strlen($maxlength)) AND (!strlen($minlength)))
					$result1 = 1;
				else
					$result1 = 0;
				switch($mode){
					case 'strict' :	$pattern = '(^[A-Za-z]+$)';			//only letters
									$result = preg_match($pattern, $string);
									break;
					
					case 'loose' :	$pattern = '(^[A-Za-z0-9]+$)';		// digits, letters
									$result = preg_match($pattern, $string);
									break;
					
					default :		$pattern = '(^[A-Za-z0-9-]+$)';		//digits, letters and hyphen
									$result = preg_match($pattern, $string);
				}
				if($result1 AND $result)
					return 1;
				else
					return 0;
			}
		}
		
		public function validatePassword($password, $minLength = 8, $maxLength = 15){
			$pattern = '((?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{'.$minLength.','.$maxLength.'})';
			return preg_match($pattern, $password);
		}
		
		public function validateEmail($email){
			$pattern = '(^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$)';
			return preg_match($pattern, $email);
		}
		
		public function validateImage($imageName){
			$pattern = '([^\s]+(?=\.(jpg|gif|png))\.\2)';
			return preg_match($pattern, $imageName);
		}
		
		public function validateDate($date){
			$pattern = '(\d{1,2}\/\d{1,2}\/\d{4})';
			return preg_match($pattern, $date);
		}
		
		public function validateNumber($number){
			$pattern = '(^[0-9]+$)';
			echo $pattern;
			return preg_match($pattern, $number);
		}
		
		public function validateContent($string){
			$string = trim($string);
			$string = str_replace("\n.", "\n..", $string);
			$string = str_replace("<", "&lt;", $string);
			$string = str_replace(">", "&gt;", $string);
			$string = str_replace("\'", "&rsquo;", $string);
			$string = str_replace("\"", "&rdquo;", $string);
			$string = str_replace("<script", "<code>&lt;script", $string);
			$string = str_replace("</script>", "&lt;/script&rt;</code>", $string);
			$string = stripslashes($string);
			return $string;
		}
		
		public function convertIntoHex($id){
			return '0x'.$id;
		}
		
		public function convertFromHex($id){
			$newID = $id.split("0x");
			return $newID[1];
		}
	}

?>