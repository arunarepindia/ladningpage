<?php
	$hostname = "localhost";
	$dbname = "indiarep_lnw1"; //database name
	$username = "indiarep_lnw"; //database username
	$pw = "^WT;GN(AwoQJ"; //database password
?>
