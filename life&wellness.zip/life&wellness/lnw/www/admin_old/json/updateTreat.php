<?php
	$name = $_POST['name'];
	$description = isset($_POST['description'])?$_POST['description']:NULL;
	$vertical = $_POST['vertical'];
	$status = $_POST['status'];
	$token = $_POST['token'];

	include_once '../../apicaller.php';
	$apicaller = new ApiCaller('APP001', '28e336ac6c9423d946ba02d19c6a2632', URL);
	$result = $apicaller->SendRequest(
		array(
			'controller' => 'treat',
			'action' => 'update',
			'name' => $name,
			'description' => $description,
			'vertical' => $vertical,
			'status' => $status,
			'token' => $token
		)
	);
	echo json_encode($result);
?>