<?php require_once('header.php'); ?>
<style>
body{
	padding-top:70px;
}
</style>
<div class="container theme-showcase" role="main">
	<div class="row">
		<!-- alert message -->
		<div class="col-md-12" id="message">
			
		</div>
		<div class="col-md-8">
			<h1 id="treatment-heading"></h1>
			<table class="table">
				<thead>
					<tr>
						<th>Country</th>
						<th>Price</th>
						<th>Options</th>
					</tr>
				</thead>
				<tbody id="treatment-body">
					
				</tbody>
			</table>
		</div>
		<div class="col-md-4">
			<div class="panel panel-default">
  				<div class="panel-heading">Associate Country</div>
  				<div class="panel-body">
					<form class="form-horizontal" role="form">
						<div class="form-group">
							<label for="inputEmail3" class="col-sm-2 control-label">Country</label>
							<div class="col-sm-10">
								<input type="hidden" name="treatment" id="treatment"/>
								<select class="form-control" id="country" name="country">
								  	
								</select>
							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-sm-2 control-label">Price</label>
							<div class="col-sm-10">
								<input type="text" class="form-control" id="price" placeholder="Enter Price in dollars">
							</div>
						</div>
						<div class="form-group">
							<div class="col-sm-12">
								<input type="submit" id="saveBtn" value="Submit" class="btn btn-success form-control"/>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
	$(document).ready( function () {
		var urlParams;
		getParam = function () {
		    var match,
		        pl     = /\+/g,  // Regex for replacing addition symbol with a space
		        search = /([^&=]+)=?([^&]*)/g,
		        decode = function (s) { return decodeURIComponent(s.replace(pl, " ")); },
		        query  = window.location.search.substring(1);

		    urlParams = {};
		    while (match = search.exec(query))
		       urlParams[decode(match[1])] = decode(match[2]);
		};
		var newHtml = '';
		getParam();
		var data = {};
		data['token'] = urlParams['treatment'];
		//console.log(data);
		$.ajax({
           	url: 'json/detailTreat.php',
           	type: "POST",
           	cache: false,
           	async: false,
           	dataType:"json",
           	data:data,
           	success: function(data, textStatus, jqXHR){
           		//onsole.log(data.data);
           		$('#treatment-heading').html(data.data.treatment[0].name);
           		$('#treatment').val(data.data.treatment[0].token);
           		if(data.data.countries.length > 0){
           			$.each(data.data.countries, function(index,value){
           				newHtml += '<tr><td>'+value['name']+'</td><td>$ '+value['price']+'</td><td><a href="#" data-token="'+value['token']+'" class="delete">Delete</a></td></tr>';
           			});
           			$('#treatment-body').html(newHtml);
           		}else{
           			newHtml = '<tr><td colspan="3">No Data Found</td></tr>'
           			$('#treatment-body').html(newHtml);
           		}
           	}, 
           	error: function(response, textStatus, jqXHR){
            	console.log(response);
           	}
      	});
		newHtml = '';
		$.ajax({
           	url: 'json/listCountry.php',
           	type: "POST",
           	cache: false,
           	async: false,
           	dataType:"json",
           	success: function(data, textStatus, jqXHR){
           		if(data.success == true){
           			//console.log(data.data);
           			$.each(data.data, function(index,value){
           				newHtml += '<option value="'+value['token']+'">'+value['name']+'</option>';
           			});
           			//console.log(newHtml);
           			$('#country').append(newHtml);
           			
           		}else{
           			newHtml = '<option value="No country found"></option>';
           			$('#country').append(newHtml);
           		}
           	}, 
           	error: function(response, textStatus, jqXHR){
            	console.log(response);
           	}
      	});

		$('#saveBtn').off('click').on('click', function(e){
			e.preventDefault();
			$('#message').empty();
			var data = {};
			data.treatment = $('#treatment').val();
			data.country = $('#country').val();
			data.price = $('#price').val();
			//console.log(data);
			var newHtml;
			$.ajax({
	           	url: 'json/addCountryTreat.php',
	           	type: "POST",
	           	cache: false,
	           	async: false,
	           	data: data,
	           	dataType:"json",
	           	success: function(data, textStatus, jqXHR){
	           		if(data.success == true){
	           			newHtml = '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>New Country is added to treatment.</div>';
	           			$('#message').append(newHtml);
	           		}else{
	           			newHtml = '<div class="alert alert-warning"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Country is not added into treatment, please fill the form properly.</div>';
	           			$('#message').append(newHtml);
	           		}
	           	}, 
	           	error: function(response, textStatus, jqXHR){
	            	newHtml = '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Oopss...Something went terribly wrong please contact RepIndia.</div>';
	           			$('#message').append(newHtml);
	           	}
          	});
		});

		$('.delete').off('click').on('click', function(e){
			e.preventDefault();
			var data = {};
			data.treatment = $('#treatment').val();
			data.country = $(this).attr('data-token');
			var newHtml;
			$.ajax({
	           	url: 'json/removeCountryTreat.php',
	           	type: "POST",
	           	cache: false,
	           	async: false,
	           	data: data,
	           	dataType:"json",
	           	success: function(data, textStatus, jqXHR){
	           		if(data.success == true){
	           			newHtml = '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Country is removed from treatment.</div>';
	           			$('#message').append(newHtml);
	           		}else{
	           			newHtml = '<div class="alert alert-warning"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Country is not removed from treatment. Something fishy going on.</div>';
	           			$('#message').append(newHtml);
	           		}
	           	}, 
	           	error: function(response, textStatus, jqXHR){
	            	newHtml = '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Oopss...Something went terribly wrong please contact RepIndia.</div>';
	           			$('#message').append(newHtml);
	           	}
          	});
		});

      	$('#treatment-table').DataTable();
	});
</script>
<?php require_once('footer.php'); ?>