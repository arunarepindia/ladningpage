<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- DataTables -->
        <script type="text/javascript" charset="utf8" src="//cdn.datatables.net/1.10.4/js/jquery.dataTables.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>
