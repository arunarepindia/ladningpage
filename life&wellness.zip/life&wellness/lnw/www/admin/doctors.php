<?php require_once('header.php'); ?>
<link href="css/select2.css" rel="stylesheet">
<script src="js/select2.min.js"></script>
<style>
body{
	padding-top:70px;
}
</style>
<div class="container theme-showcase" role="main">
	<div class="row">
		<!-- alert message -->
		<div class="col-md-12" id="message">
			
		</div>
		<div class="col-md-12">
			<h1>
				Doctors
				<button class="btn btn-success pull-right"style="margin-bottom:20px;" data-toggle="modal" data-target="#myModal">Add New Doctors</button>
			</h1>
			<br/>
		</div>
		<div class="col-md-12">
			<table class="table" id="hospital_table">
				<thead>
					<th>#</th>
					<th>Name</th>
					<th>Specialization</th>
					<th>Hospital</th>
					<th>Qualification</th>
					<td>Options</td>
				</thead>
				<tbody id="hospital_body">
					
				</tbody>
			</table>
		</div>
	</div>
</div>

<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<form class="form-horizontal" role="form">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
				<h4 class="modal-title">Add Doctor</h4>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-3 control-label">Name</label>
					<div class="col-sm-9">
						<input type="text" class="form-control" id="name" placeholder="Enter Doctor Name">
					</div>
				</div>
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-3 control-label">Specialization</label>
					<div class="col-sm-9">
						<textarea name="specialization" id="specialization" class="form-control" rows="2"></textarea>
					</div>
				</div>
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-3 control-label">Qualification</label>
					<div class="col-sm-9">
						<textarea name="qualification" id="qualification" class="form-control" rows="2"></textarea>
					</div>
				</div>
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-3 control-label">Hospital</label>
					<div class="col-sm-9">
						<select id="hospital" name="hospital" style="width:300px">
						  	
						</select>
					</div>
				</div>
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-3 control-label">Area of Specialization</label>
					<div class="col-sm-9">
						<textarea name="area" id="area" class="form-control" rows="2"></textarea>
					</div>
				</div>
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-3 control-label">Fellowship</label>
					<div class="col-sm-9">
						<textarea name="fellowship" id="fellowship" class="form-control" rows="2"></textarea>
					</div>
				</div>
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-3 control-label">Type</label>
					<div class="col-sm-9">
						<select id="type" name="type" style="width:300px">
						  	<option value="1">Medical</option>
						  	<option value="0">Aurvedic</option>
						</select>
					</div>
				</div>
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-3 control-label">Work Experience</label>
					<div class="col-sm-9">
						<textarea name="work" id="work" class="form-control" rows="2"></textarea>
					</div>
				</div>
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-3 control-label">More</label>
					<div class="col-sm-9">
						<textarea name="more" id="more" class="form-control" rows="5"></textarea>
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<button type="button" id="saveBtn" class="btn btn-success">Create</button>
			</div>
			</form>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<form class="form-horizontal" role="form">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
				<h4 class="modal-title">Modify Doctor</h4>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-3 control-label">Name</label>
					<div class="col-sm-9">
						<input type="text" class="form-control" id="mod-name" name="mod-pname" placeholder="Enter Doctor Name">
					</div>
				</div>
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-3 control-label">Specialization</label>
					<div class="col-sm-9">
						<textarea name="mod-specialization" id="mod-specialization" class="form-control" rows="2"></textarea>
					</div>
				</div>
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-3 control-label">Qualification</label>
					<div class="col-sm-9">
						<textarea name="mod-qualification" id="mod-qualification" class="form-control" rows="2"></textarea>
					</div>
				</div>
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-3 control-label">Hospital</label>
					<div class="col-sm-9">
						<select id="mod-hospital" name="mod-hospital" style="width:300px">
						  	
						</select>
					</div>
				</div>
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-3 control-label">Area of Specialization</label>
					<div class="col-sm-9">
						<textarea name="mod-area" id="mod-area" class="form-control" rows="2"></textarea>
					</div>
				</div>
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-3 control-label">Fellowship</label>
					<div class="col-sm-9">
						<textarea name="mod-fellowship" id="mod-fellowship" class="form-control" rows="2"></textarea>
					</div>
				</div>
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-3 control-label">Type</label>
					<div class="col-sm-9">
						<select id="mod-type" name="mod-type" style="width:300px">
						  	<option value="1">Medical</option>
						  	<option value="0">Aurvedic</option>
						</select>
					</div>
				</div>
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-3 control-label">Work Experience</label>
					<div class="col-sm-9">
						<textarea name="mod-work" id="mod-work" class="form-control" rows="2"></textarea>
					</div>
				</div>
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-3 control-label">More</label>
					<div class="col-sm-9">
						<textarea name="mod-more" id="mod-more" class="form-control" rows="5"></textarea>
					</div>
				</div>
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-3 control-label">Status</label>
					<div class="col-sm-9">
						<select id="mod-status" name="mod-status" style="width:300px">
						  	<option value="1">Active</option>
						  	<option value="0">Not Active</option>
						</select>
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<button type="button" id="modBtn" class="btn btn-primary">Save</button>
			</div>
			</form>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<script type="text/javascript">
	$(document).ready( function () {
		var newHtml;
      	$.ajax({
           	url: 'json/listDoctor.php',
           	type: "POST",
           	cache: false,
           	async: false,
           	dataType:"json",
           	success: function(data, textStatus, jqXHR){
           		if(data.success == true){
           			//console.log(data.data);
           			var i = 1;
           			$.each(data.data, function(index,value){
           				newHtml += '<tr><td>'+i+'</td><td>'+value['name']+'</td><td>'+value['specialization']+'</td><td>'+value['hospital']+' - '+value['state']+', '+value['country']+'</td><td>'+value['qualification']+'</td><td><a href="#" data-toggle="modal" data-target="#myModal1" data-token="'+value['token']+'" class="edit-doctor">Edit</a></td></tr>';
           				i++;
           			});
           			//console.log(newHtml);
           			$('#hospital_body').append(newHtml);
           		}else{
           			newHtml = '<tr><td colspan="4">No Data Found</td></tr>';
           			$('#hospital_body').append(newHtml);
           		}
           	}, 
           	error: function(response, textStatus, jqXHR){
            	console.log(response);
           	}
      	});
		newHtml = '';
		$.ajax({
           	url: 'json/listHospital.php',
           	type: "POST",
           	cache: false,
           	async: false,
           	dataType:"json",
           	success: function(data, textStatus, jqXHR){
           		if(data.success == true){
           			//console.log(data.data);
           			$.each(data.data, function(index,value){
           				newHtml += '<option value="'+value['token']+'">'+value['name']+' - '+value['state']+', '+value['country']+'</option>';
           			});
           			//console.log(newHtml);
           			$('#hospital').html(newHtml);
           			$('#mod-hospital').html(newHtml);
           		}else{
           			newHtml = '<option value="">No Data Found</option>';
           			$('#country').html(newHtml);
           			$('#mod-country').html(newHtml);
           		}
           	}, 
           	error: function(response, textStatus, jqXHR){
            	console.log(response);
           	}
      	});
		

		$('#saveBtn').off('click').on('click', function(e){
			e.preventDefault();
			$('#message').empty();
			var data = {};
			data.name = $('#name').val();
			data.specialization = $('#specialization').val();
			data.qualification = $('#qualification').val();
			data.hospital = $('#hospital').val();
			data.area = $('#area').val();
			data.fellowship = $('#fellowship').val();
			data.type = $('#type').val();
			data.more = $('#more').val();
			data.work = $('#work').val();
			var newHtml;
			$.ajax({
	           	url: 'json/addDoctor.php',
	           	type: "POST",
	           	cache: false,
	           	async: false,
	           	data: data,
	           	dataType:"json",
	           	success: function(data, textStatus, jqXHR){
	           		if(data.success == true){
	           			newHtml = '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>New Doctor is created successfully.</div>';
	           			$('#message').append(newHtml);
	           		}else{
	           			newHtml = '<div class="alert alert-warning"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Doctor is not created, please fill the form properly.</div>';
	           			$('#message').append(newHtml);
	           		}
	           		$('#myModal').modal('hide');
	           	}, 
	           	error: function(response, textStatus, jqXHR){
	            	newHtml = '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Oopss...Something went terribly wrong please contact RepIndia.</div>';
	           			$('#message').append(newHtml);
	           		console.log(response);
	           	}
          	});
		});
		
		$('.edit-doctor').off('click').on('click', function(e){
			//e.preventDefault();
			$('#message').empty();
			var data = {};
			data['token'] = $(this).attr('data-token');
			$.ajax({
	           	url: 'json/getDoctor.php',
	           	type: "POST",
	           	cache: false,
	           	async: false,
	           	data: data,
	           	dataType:"json",
	           	success: function(data, textStatus, jqXHR){
	           		console.log(data);
	           		$('#mod-name').val(data.data.name);
	           		$('#mod-qualification').val(data.data.qualification);
	           		$('#mod-specialization').val(data.data.specialization);
	           		$('#mod-type').val(data.data.type);
	           		$('#mod-area').val(data.data.area);
	           		$('#mod-more').val(data.data.more);
	           		$('#mod-work').val(data.data.work);
	           		$('#mod-fellowship').val(data.data.fellow);
	           		$('#mod-status').val(data.data.status);
	           	},
	           	error: function(response, textStatus, jqXHR){
	            	console.log(response);
	            	newHtml = '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Oopss...Something went terribly wrong please contact RepIndia.</div>';
	           			$('#message').append(newHtml);
	           	}
          	});

          	$('#modBtn').off('click').on('click', function(e){
          		$('#message').empty();
          		data.name = $('#mod-name').val();
				data.specialization = $('#mod-specialization').val();
				data.qualification = $('#mod-qualification').val();
				data.hospital = $('#mod-hospital').val();
				data.area = $('#mod-area').val();
				data.fellowship = $('#mod-fellowship').val();
				data.type = $('#mod-type').val();
				data.more = $('#mod-more').val();
				data.work = $('#mod-work').val();
				data.status = $('#mod-status').val();
				//console.log(data);
				$.ajax({
		           	url: 'json/updateDoctor.php',
		           	type: "POST",
		           	cache: false,
		           	async: false,
		           	data: data,
		           	dataType:"json",
		           	success: function(data, textStatus, jqXHR){
		           		if(data.success == true){
		           			newHtml = '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Doctor is successfully updated. Please refresh your page.</div>';
		           			$('#message').append(newHtml);
		           			$('#myModal1').modal('hide');
		           		}else{
		           			newHtml = '<div class="alert alert-warning"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Doctor is not updated, please fill the form properly.</div>';
		           			$('#message').append(newHtml);
		           		}
		           	},
		           	error: function(response, textStatus, jqXHR){
		            	console.log(response);
		            	newHtml = '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Oopss...Something went terribly wrong please contact RepIndia.</div>';
		           			$('#message').append(newHtml);
		           	}
	          	});
          	});
		});

		$("#type").select2({
			 placeholder: "Select Type of Doctor"
		});
		$("#hospital").select2({
			 placeholder: "Select Hospitals"
		});
		$("#mod-type").select2({
			 placeholder: "Select Type of Doctor"
		});
		$("#mod-hospital").select2({
			 placeholder: "Select Hospitals"
		});
		$('#hospital_table').DataTable();
	});
</script>
<?php require_once('footer.php'); ?>