<?php require_once('header.php'); ?>
<div class="container theme-showcase" role="main">
	<div class="row">
		<!-- alert message -->
		<div class="col-md-12" id="message">
			
		</div>
		<div class="col-md-7">
			<table class="table" id="state_table">
				<thead>
					<th>#</th>
					<th>Name</th>
					<th>Code</th>
					<th>Country</th>
					<th>Option</th>
				</thead>
				<tbody id="state_body">
					
				</tbody>
			</table>
		</div>
		<div class="col-md-1"></div>
		<div class="col-md-4">
			<div class="panel panel-default">
  				<div class="panel-heading">Add New City</div>
  				<div class="panel-body">
					<form class="form-horizontal" role="form">
						<div class="form-group">
							<label for="inputEmail3" class="col-sm-2 control-label">Name</label>
							<div class="col-sm-10">
								<input type="text" class="form-control" id="sname" placeholder="Enter City Name">
							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-sm-2 control-label">Code</label>
							<div class="col-sm-10">
								<input type="text" class="form-control" id="scode" placeholder="Enter City Code">
							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-sm-2 control-label">Country</label>
							<div class="col-sm-10">
								<select class="form-control" id="scountry" name="country">
								  	
								</select>
							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-sm-2 control-label">Status</label>
							<div class="col-sm-10">
								<select class="form-control" id="sstatus" name="status">
								  	<option value="1">Active</option>
								  	<option value="0">Delete</option>
								</select>
							</div>
						</div>
						<div class="form-group">
							<div class="col-sm-12">
								<input type="submit" id="saveBtn" value="Submit" class="btn btn-success form-control"/>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div> <!-- /container -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<form class="form-horizontal" role="form">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
				<h4 class="modal-title">Modify City</h4>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-2 control-label">Name</label>
					<div class="col-sm-10">
						<input type="text" class="form-control" id="mod-sname" placeholder="Enter City Name">
					</div>
				</div>
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-2 control-label">Code</label>
					<div class="col-sm-10">
						<input type="text" class="form-control" id="mod-scode" placeholder="Enter City Code">
					</div>
				</div>
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-2 control-label">Country</label>
					<div class="col-sm-10">
						<select class="form-control" name="mod-country" id="mod-country">
						  	
						</select>
					</div>
				</div>
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-2 control-label">Status</label>
					<div class="col-sm-10">
						<select class="form-control" name="mod-status" id="mod-status">
						  	<option value="1">Active</option>
						  	<option value="0">Delete</option>
						</select>
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<button type="button" id="modBtn" class="btn btn-primary">Save changes</button>
			</div>
			</form>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<script type="text/javascript">
	$(document).ready( function () {
		//$('#state_table').DataTable();

		var newHtml = '';

		$.ajax({
           	url: 'json/listState.php',
           	type: "POST",
           	cache: false,
           	async: false,
           	dataType:"json",
           	success: function(data, textStatus, jqXHR){
           		if(data.success == true){
           			var i = 1;
           			$.each(data.data, function(index,value){
           				newHtml += '<tr><td>'+i+'</td><td>'+value['name']+'</td><td>'+value['code']+'</td><td>'+value['country']+'</td><td><a href="#" data-toggle="modal" data-target="#myModal" data-token="'+value['token']+'" class="edit-state">Edit</a></td></tr>';
           				i++;
           			});
           			//console.log(newHtml);
           			$('#state_body').html(newHtml);
           			$('#state_table').DataTable();
           		}else{
           			newHtml = '<tr><td colspan="4">No Data Found</td></tr>';
           			$('#state_body').html(newHtml);
           		}
           	}, 
           	error: function(response, textStatus, jqXHR){
            	console.log(response);
           	}
      	});
		newHtml = '';
		$.ajax({
           	url: 'json/listCountry.php',
           	type: "POST",
           	cache: false,
           	async: false,
           	dataType:"json",
           	success: function(data, textStatus, jqXHR){
           		if(data.success == true){
           			//console.log(data.data);
           			$.each(data.data, function(index,value){
           				newHtml += '<option value="'+value['token']+'">'+value['name']+'</option>';
           			});
           			//console.log(newHtml);
           			$('#scountry').html(newHtml);
           			$('#mod-country').html(newHtml);
           		}else{
           			newHtml += '<option value="">No Country Found</option>';
           			$('#scountry').html(newHtml);
           			$('#mod-country').html(newHtml);
           		}
           	}, 
           	error: function(response, textStatus, jqXHR){
            	console.log(response);
           	}
      	});

      	$('#saveBtn').off('click').on('click', function(e){
			e.preventDefault();
			$('#message').empty();
			var data = {};
			data['name'] = $('#sname').val();
			data['code'] = $('#scode').val();
			data['country'] = $('#scountry').val();
			data['status'] = $('#sstatus').val();
			//console.log(data);
			var newHtml;
			$.ajax({
	           	url: 'json/addState.php',
	           	type: "POST",
	           	cache: false,
	           	async: false,
	           	data: data,
	           	dataType:"json",
	           	success: function(data, textStatus, jqXHR){
	           		if(data.success == true){
	           			newHtml = '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>New State is created successfully.</div>';
	           			$('#message').append(newHtml);
	           		}else{
	           			newHtml = '<div class="alert alert-warning"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>State is not created, please fill the form properly.</div>';
	           			$('#message').append(newHtml);
	           		}
	           	}, 
	           	error: function(response, textStatus, jqXHR){
	            	newHtml = '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Oopss...Something went terribly wrong please contact RepIndia.</div>';
	           			$('#message').append(newHtml);
	           	}
          	});
		});
		
		$('.edit-state').off('click').on('click', function(e){
			//e.preventDefault();
			$('#message').empty();
			var data = {};
			data['token'] = $(this).attr('data-token');
			$.ajax({
	           	url: 'json/getState.php',
	           	type: "POST",
	           	cache: false,
	           	async: false,
	           	data: data,
	           	dataType:"json",
	           	success: function(data, textStatus, jqXHR){
	           		console.log(data);
	           		$('#mod-sname').val(data.data.name);
	           		$('#mod-scode').val(data.data.code);
	           		$('#mod-country').val(data.data.countryID);
	           		$('#mod-sstatus').val(data.data.status);
	           	},
	           	error: function(response, textStatus, jqXHR){
	            	console.log(response);
	            	newHtml = '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Oopss...Something went terribly wrong please contact RepIndia.</div>';
	           			$('#message').append(newHtml);
	           	}
          	});

          	$('#modBtn').off('click').on('click', function(e){
          		$('#message').empty();
          		data['name'] = $('#mod-sname').val();
				data['code'] = $('#mod-scode').val();
				data['country'] = $('#mod-country').val();
				data['status'] = $('#mod-sstatus').val();

				$.ajax({
		           	url: 'json/updateState	.php',
		           	type: "POST",
		           	cache: false,
		           	async: false,
		           	data: data,
		           	dataType:"json",
		           	success: function(data, textStatus, jqXHR){
		           		if(data.success == true){
		           			newHtml = '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Country is successfully updated. Please refresh your page.</div>';
		           			$('#message').append(newHtml);
		           			$('#myModal').modal('hide');
		           		}else{
		           			newHtml = '<div class="alert alert-warning"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Country is not updated, please fill the form properly.</div>';
		           			$('#message').append(newHtml);
		           		}
		           	},
		           	error: function(response, textStatus, jqXHR){
		            	console.log(response);
		            	newHtml = '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Oopss...Something went terribly wrong please contact RepIndia.</div>';
		           			$('#message').append(newHtml);
		           	}
	          	});
          	});
		});
	});
</script>
<?php require_once('footer.php'); ?>