<?php require_once('header.php'); ?>
<div class="container theme-showcase" role="main">
	<div class="row">
		<!-- alert message -->
		<div class="col-md-12" id="message">
			
		</div>

		<div class="col-md-7">
			<table class="table" id="state_table">
				<thead>
					<th>#</th>
					<th>Name</th>
					<th>Code</th>
					<th>Option</th>
				</thead>
				<tbody id="state_body">
					
				</tbody>
			</table>
		</div>
		<div class="col-md-1"></div>
		<div class="col-md-4">
			<div class="panel panel-default">
  				<div class="panel-heading">Add New Country</div>
  				<div class="panel-body">
					<form class="form-horizontal" role="form">
						<div class="form-group">
							<label for="inputEmail3" class="col-sm-2 control-label">Name</label>
							<div class="col-sm-10">
								<input type="text" class="form-control" id="cname" placeholder="Enter Country Name">
							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-sm-2 control-label">Code</label>
							<div class="col-sm-10">
								<input type="text" class="form-control" id="ccode" placeholder="Enter Country Code">
							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-sm-2 control-label">Status</label>
							<div class="col-sm-10">
								<select class="form-control" id="cstatus" name="cstatus">
								  	<option value="1">Active</option>
								  	<option value="0">Not Active</option>
								</select>
							</div>
						</div>
						<div class="form-group">
							<div class="col-sm-12">
								<input type="submit" id="saveBtn" value="Submit" class="btn btn-success form-control"/>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div> <!-- /container -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<form class="form-horizontal" role="form">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
				<h4 class="modal-title">Modify Country</h4>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-2 control-label">Name</label>
					<div class="col-sm-10">
						<input type="text" class="form-control" id="mod-cname" placeholder="Enter Country Name">
					</div>
				</div>
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-2 control-label">Code</label>
					<div class="col-sm-10">
						<input type="text" class="form-control" id="mod-ccode" placeholder="Enter Country Code">
					</div>
				</div>
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-2 control-label">Status</label>
					<div class="col-sm-10">
						<select class="form-control" name="mod-status" id="mod-cstatus">
						  	<option value="1">Active</option>
						  	<option value="0">Not Active</option>
						</select>
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<button type="button" id="modBtn" class="btn btn-primary">Save changes</button>
			</div>
			</form>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<script type="text/javascript">
	$(document).ready( function () {
		var newHtml;

		$.ajax({
           	url: 'json/listCountry.php',
           	type: "POST",
           	cache: false,
           	async: false,
           	dataType:"json",
           	success: function(data, textStatus, jqXHR){
           		if(data.success == true){
           			var i = 1;
           			//console.log(data.data);
           			$.each(data.data, function(index,value){
           				newHtml += '<tr><td>'+i+'</td><td>'+value['name']+'</td><td>'+value['code']+'</td><td><a href="#" data-toggle="modal" data-target="#myModal" data-token="'+value['token']+'" class="edit-country">Edit</a></td></tr>';
           				i++;
           			});
           			//console.log(newHtml);
           			$('#state_body').append(newHtml);
           			$('#state_table').DataTable();
           		}else{
           			newHtml = '<tr><td colspan="4">No Data Found</td></tr>';
           			$('#state_body').append(newHtml);
           		}
           	}, 
           	error: function(response, textStatus, jqXHR){
            	console.log(response);
           	}
      	});

		$('#saveBtn').off('click').on('click', function(e){
			e.preventDefault();
			$('#message').empty();
			var data = {};
			data['name'] = $('#cname').val();
			data['code'] = $('#ccode').val();
			data['status'] = $('#cstatus').val();
			var newHtml;
			$.ajax({
	           	url: 'json/addCountry.php',
	           	type: "POST",
	           	cache: false,
	           	async: false,
	           	data: data,
	           	dataType:"json",
	           	success: function(data, textStatus, jqXHR){
	           		if(data.success == true){
	           			newHtml = '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>New Country is created successfully.</div>';
	           			$('#message').append(newHtml);
	           		}else{
	           			newHtml = '<div class="alert alert-warning"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Country is not created, please fill the form properly.</div>';
	           			$('#message').append(newHtml);
	           		}
	           	}, 
	           	error: function(response, textStatus, jqXHR){
	            	newHtml = '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Oopss...Something went terribly wrong please contact RepIndia.</div>';
	           			$('#message').append(newHtml);
	           	}
          	});
		});

		$('.edit-country').off('click').on('click', function(e){
			//e.preventDefault();
			$('#message').empty();
			var data = {};
			data['token'] = $(this).attr('data-token');
			$.ajax({
	           	url: 'json/getCountry.php',
	           	type: "POST",
	           	cache: false,
	           	async: false,
	           	data: data,
	           	dataType:"json",
	           	success: function(data, textStatus, jqXHR){
	           		console.log(data);
	           		$('#mod-cname').val(data.data.name);
	           		$('#mod-ccode').val(data.data.code);
	           		$('#mod-cstatus').val(data.data.status);
	           	},
	           	error: function(response, textStatus, jqXHR){
	            	console.log(response);
	            	newHtml = '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Oopss...Something went terribly wrong please contact RepIndia.</div>';
	           			$('#message').append(newHtml);
	           	}
          	});

          	$('#modBtn').off('click').on('click', function(e){
          		$('#message').empty();
          		data['name'] = $('#mod-cname').val();
				data['code'] = $('#mod-ccode').val();
				data['status'] = $('#mod-cstatus').val();

				$.ajax({
		           	url: 'json/updateCountry.php',
		           	type: "POST",
		           	cache: false,
		           	async: false,
		           	data: data,
		           	dataType:"json",
		           	success: function(data, textStatus, jqXHR){
		           		if(data.success == true){
		           			newHtml = '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Country is successfully updated. Please refresh your page.</div>';
		           			$('#message').append(newHtml);
		           			$('#myModal').modal('hide');
		           		}else{
		           			newHtml = '<div class="alert alert-warning"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Country is not updated, please fill the form properly.</div>';
		           			$('#message').append(newHtml);
		           		}
		           	},
		           	error: function(response, textStatus, jqXHR){
		            	console.log(response);
		            	newHtml = '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Oopss...Something went terribly wrong please contact RepIndia.</div>';
		           			$('#message').append(newHtml);
		           	}
	          	});
          	});
		});
	});
</script>
<?php require_once('footer.php'); ?>