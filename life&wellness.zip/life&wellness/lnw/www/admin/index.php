<?php require_once('header.php'); ?>
    <div class="container theme-showcase" role="main">

      

    </div> <!-- /container -->

<?php require_once('footer.php'); ?>