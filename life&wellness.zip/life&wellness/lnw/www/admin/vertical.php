<?php require_once('header.php'); ?>
<style>
body{
	padding-top:70px;
}
</style>
<div class="container theme-showcase" role="main">
	<div class="row">
		<!-- alert message -->
		<div class="col-md-12" id="message">
			
		</div>
		<div class="col-md-8">
			<h1 id="treatment-heading"></h1><br/>
			<table class="table" id="country-table">
				<thead>
					<tr>
						<th>Country</th>
						<th>Options</th>
					</tr>
				</thead>
				<tbody id="treatment-body">
					
				</tbody>
			</table>
			<br/><br/>
			<table class="table" id="doctor-table">
				<thead>
					<tr>
						<th>Doctors</th>
						<th>Options</th>
					</tr>
				</thead>
				<tbody id="treatment-body1">
					
				</tbody>
			</table>
		</div>
		<div class="col-md-4">
			<div class="panel panel-default">
  				<div class="panel-heading">Associate Country</div>
  				<div class="panel-body">
					<form class="form-horizontal" role="form">
						<div class="form-group">
							<label for="inputEmail3" class="col-sm-2 control-label">Country</label>
							<div class="col-sm-10">
								<input type="hidden" name="treatment" id="treatment"/>
								<select class="form-control" id="country" name="country">
								  	
								</select>
							</div>
						</div>
						<div class="form-group">
							<div class="col-sm-12">
								<input type="submit" id="saveBtn" value="Submit" class="btn btn-success form-control"/>
							</div>
						</div>
					</form>
				</div>
			</div>

			<div class="panel panel-default">
  				<div class="panel-heading">Associate Doctor</div>
  				<div class="panel-body">
					<form class="form-horizontal" role="form">
						<div class="form-group">
							<label for="inputEmail3" class="col-sm-2 control-label">Doctor</label>
							<div class="col-sm-10">
								<select class="form-control" id="doctor" name="doctor">
								  	
								</select>
							</div>
						</div>
						<div class="form-group">
							<div class="col-sm-12">
								<input type="submit" id="saveBtn1" value="Submit" class="btn btn-success form-control"/>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
	$(document).ready( function () {
		var urlParams;
		getParam = function () {
		    var match,
		        pl     = /\+/g,  // Regex for replacing addition symbol with a space
		        search = /([^&=]+)=?([^&]*)/g,
		        decode = function (s) { return decodeURIComponent(s.replace(pl, " ")); },
		        query  = window.location.search.substring(1);

		    urlParams = {};
		    while (match = search.exec(query))
		       urlParams[decode(match[1])] = decode(match[2]);
		};
		var newHtml = '';
		getParam();
		var data = {};
		data['token'] = urlParams['vertical'];
		//console.log(data);
		$.ajax({
           	url: 'json/detailTreatment.php',
           	type: "POST",
           	cache: false,
           	async: false,
           	dataType:"json",
           	data:data,
           	success: function(data, textStatus, jqXHR){
           		//console.log(data.data);
           		var i = 0;
           		$('#treatment-heading').html('Vertical - '+data.data.info[0]['name']);
           		$('#treatment').val(data.data.info[0]['token']);
           		$.each(data.data.countries, function(index,value){
           			i++;
           			//console.log(value);
           			newHtml += '<tr><td>'+value['name']+'</td><td><a href="#" data-country="'+value['token']+'" data-treatment="'+data.data.info[0]['token']+'" class="delete-country">Delete</a></td></tr>';
           		});
           		$('#treatment-body').html(newHtml);
           		if(i == 0){
           			newHtml = '<tr><td colspan="3">No Data Found</td></tr>'
           			$('#treatment-body').html(newHtml);
           		}
           		newHtml = '';
           		$.each(data.data.doctors, function(index,value){
           			i++;
           			newHtml += '<tr><td>'+value['name']+'</td><td><a href="#" data-doctor="'+value['token']+'" data-treatment="'+data.data.info[0]['token']+'" class="delete-doctor">Delete</a></td></tr>';
           		});
           		$('#treatment-body1').html(newHtml);
           		if(i == 0){
           			newHtml = '<tr><td colspan="3">No Data Found</td></tr>'
           			$('#treatment-body1').html(newHtml);
           		}
           	}, 
           	error: function(response, textStatus, jqXHR){
            	console.log(response);
           	}
      	});
		newHtml = '';
		$.ajax({
           	url: 'json/listCountry.php',
           	type: "POST",
           	cache: false,
           	async: false,
           	dataType:"json",
           	success: function(data, textStatus, jqXHR){
           		if(data.success == true){
           			//console.log(data.data);
           			$.each(data.data, function(index,value){
           				newHtml += '<option value="'+value['token']+'">'+value['name']+'</option>';
           			});
           			//console.log(newHtml);
           			$('#country').append(newHtml);
           			
           		}else{
           			newHtml = '<option value="No country found"></option>';
           			$('#country').append(newHtml);
           		}
           	}, 
           	error: function(response, textStatus, jqXHR){
            	console.log(response);
           	}
      	});

      	newHtml = '';
		$.ajax({
           	url: 'json/listDoctor.php',
           	type: "POST",
           	cache: false,
           	async: false,
           	dataType:"json",
           	success: function(data, textStatus, jqXHR){
           		if(data.success == true){
           			//console.log(data.data);
           			$.each(data.data, function(index,value){
           				newHtml += '<option value="'+value['token']+'">'+value['name']+'</option>';
           			});
           			//console.log(newHtml);
           			$('#doctor').html(newHtml);
           			
           		}else{
           			newHtml = '<option value="No country found"></option>';
           			$('#doctor').html(newHtml);
           		}
           	}, 
           	error: function(response, textStatus, jqXHR){
            	console.log(response);
           	}
      	});

		$('#saveBtn').off('click').on('click', function(e){
			e.preventDefault();
			$('#message').empty();
			var data = {};
			data.treatment = $('#treatment').val();
			data.country = $('#country').val();
			console.log(data);
			var newHtml;
			$.ajax({
	           	url: 'json/addCountryToTreatment.php',
	           	type: "POST",
	           	cache: false,
	           	async: false,
	           	data: data,
	           	dataType:"json",
	           	success: function(data, textStatus, jqXHR){
	           		if(data.success == true){
	           			newHtml = '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>New Country is added to vertical.</div>';
	           			$('#message').append(newHtml);
	           		}else{
	           			newHtml = '<div class="alert alert-warning"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Country is not added into vertical, please fill the form properly.</div>';
	           			$('#message').append(newHtml);
	           		}
	           	}, 
	           	error: function(response, textStatus, jqXHR){
	            	console.log(response);
	            	newHtml = '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Oopss...Something went terribly wrong please contact RepIndia.</div>';
	           			$('#message').append(newHtml);
	           	}
          	});
		});

		$('#saveBtn1').off('click').on('click', function(e){
			e.preventDefault();
			$('#message').empty();
			var data = {};
			data.treatment = $('#treatment').val();
			data.doctor = $('#doctor').val();
			//console.log(data);
			var newHtml;
			$.ajax({
	           	url: 'json/addDoctorToTreatment.php',
	           	type: "POST",
	           	cache: false,
	           	async: false,
	           	data: data,
	           	dataType:"json",
	           	success: function(data, textStatus, jqXHR){
	           		if(data.success == true){
	           			newHtml = '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>New Doctor is added to vertical.</div>';
	           			$('#message').append(newHtml);
	           		}else{
	           			newHtml = '<div class="alert alert-warning"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Doctor is not added into vertical, please fill the form properly.</div>';
	           			$('#message').append(newHtml);
	           		}
	           	}, 
	           	error: function(response, textStatus, jqXHR){
	            	newHtml = '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Oopss...Something went terribly wrong please contact RepIndia.</div>';
	           			$('#message').append(newHtml);
	           	}
          	});
		});

		$('.delete-country').off('click').on('click', function(e){
			e.preventDefault();
			var data = {};
			data.treatment = $(this).attr('data-treatment');
			data.country = $(this).attr('data-country');
			var newHtml;
			$.ajax({
	           	url: 'json/removeCountryFromTreatment.php',
	           	type: "POST",
	           	cache: false,
	           	async: false,
	           	data: data,
	           	dataType:"json",
	           	success: function(data, textStatus, jqXHR){
	           		if(data.success == true){
	           			newHtml = '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Country is removed from treatment.</div>';
	           			$('#message').append(newHtml);
	           		}else{
	           			newHtml = '<div class="alert alert-warning"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Country is not removed from treatment. Something fishy going on.</div>';
	           			$('#message').append(newHtml);
	           		}
	           	}, 
	           	error: function(response, textStatus, jqXHR){
	            	console.log(response);
	            	newHtml = '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Oopss...Something went terribly wrong please contact RepIndia.</div>';
	           			$('#message').append(newHtml);
	           	}
          	});
		});

		$('.delete-doctor').off('click').on('click', function(e){
			e.preventDefault();
			var data = {};
			data.treatment = $(this).attr('data-treatment');
			data.doctor = $(this).attr('data-doctor');
			var newHtml;
			$.ajax({
	           	url: 'json/removeDoctorFromTreatment.php',
	           	type: "POST",
	           	cache: false,
	           	async: false,
	           	data: data,
	           	dataType:"json",
	           	success: function(data, textStatus, jqXHR){
	           		if(data.success == true){
	           			newHtml = '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Doctor is removed from treatment.</div>';
	           			$('#message').append(newHtml);
	           		}else{
	           			newHtml = '<div class="alert alert-warning"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Doctor is not removed from treatment. Something fishy going on.</div>';
	           			$('#message').append(newHtml);
	           		}
	           	}, 
	           	error: function(response, textStatus, jqXHR){
	            	console.log(response);
	            	newHtml = '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Oopss...Something went terribly wrong please contact RepIndia.</div>';
	           			$('#message').append(newHtml);
	           	}
          	});
		});

      	$('#country-table').DataTable();
      	$('#doctor-table').DataTable();
	});
</script>
<?php require_once('footer.php'); ?>