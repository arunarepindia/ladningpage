<?php require_once('header.php'); ?>
<div class="container theme-showcase" role="main">
	<div class="row">
		<!-- alert message -->
		<div class="col-md-12" id="message">
			
		</div>
		<div class="col-md-7">
			<table class="table" id="hospital_table">
				<thead>
					<th>#</th>
					<th>Name</th>
					<th>State</th>
					<th>Country</th>
					<th>Option</th>
				</thead>
				<tbody id="hospital_body">
					
				</tbody>
			</table>
		</div>
		<div class="col-md-1"></div>
		<div class="col-md-4">
			<div class="panel panel-default">
  				<div class="panel-heading">Add New Hospital</div>
  				<div class="panel-body">
					<form class="form-horizontal" role="form">
						<div class="form-group">
							<label for="inputEmail3" class="col-sm-2 control-label">Name</label>
							<div class="col-sm-10">
								<input type="text" class="form-control" id="name" placeholder="Enter Hospital Name">
							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-sm-2 control-label">Street Address</label>
							<div class="col-sm-10">
								<textarea name="street-address" id="street-address" class="form-control" rows="5"></textarea>
							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-sm-2 control-label">Country</label>
							<div class="col-sm-10">
								<select class="form-control country" id="country" name="country">
								  	<option value="">Select Country</option>
								</select>
							</div>
						</div>
						<div class="form-group">
							<label for="inputEmail3" class="col-sm-2 control-label">State</label>
							<div class="col-sm-10">
								<select class="form-control state" id="state" name="state">
								  	<option value="">Select State</option>
								</select>
							</div>
						</div>
						<div class="form-group">
							<div class="col-sm-12">
								<input type="submit" id="saveBtn" value="Submit" class="btn btn-success form-control"/>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div> <!-- /container -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<form class="form-horizontal" role="form">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
				<h4 class="modal-title">Modify Hospital</h4>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-2 control-label">Name</label>
					<div class="col-sm-10">
						<input type="text" class="form-control" id="mod-name" placeholder="Enter Hospital Name">
					</div>
				</div>
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-2 control-label">Street Address</label>
					<div class="col-sm-10">
						<textarea name="street-address" id="mod-address" class="form-control" rows="5"></textarea>
					</div>
				</div>
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-2 control-label">Country</label>
					<div class="col-sm-10">
						<select class="form-control country" id="mod-country" name="country">
						  	<option value="">Select Country</option>
						</select>
					</div>
				</div>
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-2 control-label">State</label>
					<div class="col-sm-10">
						<select class="form-control state" id="mod-state" name="state">
						  	<option value="">Select State</option>
						</select>
					</div>
				</div>
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-2 control-label">Status</label>
					<div class="col-sm-10">
						<select class="form-control" name="mod-status" id="mod-status">
						  	<option value="1">Active</option>
						  	<option value="0">Not Active</option>
						</select>
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<button type="button" id="modBtn" class="btn btn-primary">Save changes</button>
			</div>
			</form>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<script type="text/javascript">
	$(document).ready( function () {
		var newHtml;

		$.ajax({
           	url: 'json/listCountry.php',
           	type: "POST",
           	cache: false,
           	async: false,
           	dataType:"json",
           	success: function(data, textStatus, jqXHR){
           		if(data.success == true){
           			//console.log(data.data);
           			$.each(data.data, function(index,value){
           				newHtml += '<option value="'+value['token']+'">'+value['name']+'</option>';
           			});
           			//console.log(newHtml);
           			$('#country').append(newHtml);
           			$('#mod-country').append(newHtml);
           		}else{
           			newHtml = '<option value="">No Data Found</option>';
           			$('#country').append(newHtml);
           			$('#mod-country').append(newHtml);
           		}
           	}, 
           	error: function(response, textStatus, jqXHR){
            	console.log(response);
           	}
      	});
		newHtml = '';
      	$.ajax({
           	url: 'json/listHospital.php',
           	type: "POST",
           	cache: false,
           	async: false,
           	dataType:"json",
           	success: function(data, textStatus, jqXHR){
           		if(data.success == true){
           			//console.log(data.data);
           			var i = 1;
           			$.each(data.data, function(index,value){
           				newHtml += '<tr><td>'+i+'</td><td>'+value['name']+'</td><td>'+value['state']+'</td><td>'+value['country']+'</td><td><a href="#" data-toggle="modal" data-target="#myModal" data-token="'+value['token']+'" class="edit-hospital">Edit</a></td></tr>';
           				i++;
           			});
           			//console.log(newHtml);
           			$('#hospital_body').append(newHtml);
           		}else{
           			newHtml = '<tr><td colspan="4">No Data Found</td></tr>';
           			$('#hospital_body').append(newHtml);
           		}
           	}, 
           	error: function(response, textStatus, jqXHR){
            	console.log(response);
           	}
      	});
		newHtml = '';
      	$('.country').on('change', function(e){
      		//console.log('ok');
      		countryID = $(this).val();
      		data = {};
      		newHtml = '';
      		data['country'] = countryID;
      		$.ajax({
	           	url: 'json/filterState.php',
	           	type: "POST",
	           	data: data,
	           	cache: false,
	           	async: false,
	           	dataType:"json",
	           	success: function(data, textStatus, jqXHR){
	           		console.log(data);
	           		if(data.success == true){
	           			//console.log(data.data);
	           			$.each(data.data, function(index,value){
	           				newHtml += '<option value="'+value['token']+'">'+value['name']+'</option>';
	           			});
	           			//console.log(newHtml);
	           			$('#state').html(newHtml);
	           			$('#mod-state').html(newHtml);
	           		}else{
	           			newHtml = '<option value="">No Data Found</option>';
	           			$('#state').html(newHtml);
	           			$('#mod-state').html(newHtml);
	           		}
	           	}, 
	           	error: function(response, textStatus, jqXHR){
	            	console.log(response);
	           	}
	      	});
      	});
		$('#hospital_table').DataTable();
		$('#saveBtn').off('click').on('click', function(e){
			e.preventDefault();
			$('#message').empty();
			var data = {};
			data['name'] = $('#name').val();
			data['address'] = $('#street-address').val();
			data['stateID'] = $('#state').val();
			data['countryID'] = $('#country').val();
			//console.log(data);
			var newHtml;
			$.ajax({
	           	url: 'json/addHospital.php',
	           	type: "POST",
	           	cache: false,
	           	async: false,
	           	data: data,
	           	dataType:"json",
	           	success: function(data, textStatus, jqXHR){
	           		if(data.success == true){
	           			newHtml = '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>New Hospital is created successfully.</div>';
	           			$('#message').append(newHtml);
	           		}else{
	           			newHtml = '<div class="alert alert-warning"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Hospital  is not created, please fill the form properly.</div>';
	           			$('#message').append(newHtml);
	           		}
	           	}, 
	           	error: function(response, textStatus, jqXHR){
	            	newHtml = '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Oopss...Something went terribly wrong please contact RepIndia.</div>';
	           			$('#message').append(newHtml);
	           	}
          	});
		});

		
		$('.edit-hospital').off('click').on('click', function(e){
			//e.preventDefault();
			$('#message').empty();
			var data = {};
			data['token'] = $(this).attr('data-token');
			$.ajax({
	           	url: 'json/getHospital.php',
	           	type: "POST",
	           	cache: false,
	           	async: false,
	           	data: data,
	           	dataType:"json",
	           	success: function(data, textStatus, jqXHR){
	           		console.log(data);
	           		$('#mod-name').val(data.data.name);
	           		$('#mod-address').val(data.data.address);
	           		$('#mod-state').val(data.data.stateID);
	           		$('#mod-country').val(data.data.countryID);
	           		$('#mod-status').val(data.data.status);
	           	},
	           	error: function(response, textStatus, jqXHR){
	            	console.log(response);
	            	newHtml = '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Oopss...Something went terribly wrong please contact RepIndia.</div>';
	           			$('#message').append(newHtml);
	           	}
          	});

          	$('#modBtn').off('click').on('click', function(e){
          		$('#message').empty();
          		data['name'] = $('#mod-name').val();
				data['address'] = $('#mod-address').val();
				data['state'] = $('#mod-state').val();
				data['country'] = $('#mod-country').val();
				data['status'] = $('#mod-status').val();
				//console.log(data);
				$.ajax({
		           	url: 'json/updateHospital.php',
		           	type: "POST",
		           	cache: false,
		           	async: false,
		           	data: data,
		           	dataType:"json",
		           	success: function(data, textStatus, jqXHR){
		           		if(data.success == true){
		           			newHtml = '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Hospital is successfully updated. Please refresh your page.</div>';
		           			$('#message').append(newHtml);
		           			$('#myModal').modal('hide');
		           		}else{
		           			newHtml = '<div class="alert alert-warning"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Hospital is not updated, please fill the form properly.</div>';
		           			$('#message').append(newHtml);
		           		}
		           	},
		           	error: function(response, textStatus, jqXHR){
		            	console.log(response);
		            	newHtml = '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Oopss...Something went terribly wrong please contact RepIndia.</div>';
		           			$('#message').append(newHtml);
		           	}
	          	});
          	});
		});

	});
</script>
<?php require_once('footer.php'); ?>