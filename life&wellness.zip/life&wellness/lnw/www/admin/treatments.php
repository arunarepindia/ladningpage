<?php require_once('header.php'); ?>
<link href="css/select2.css" rel="stylesheet">
<script src="js/select2.min.js"></script>
<style>
body{
	padding-top:70px;
}
</style>
<div class="container theme-showcase" role="main">
	<div class="row">
		<!-- alert message -->
		<div class="col-md-12" id="message">
			
		</div>
		<div class="col-md-12">
			<h1>
				Treatments	
				<button class="btn btn-success pull-right"style="margin-bottom:20px;" data-toggle="modal" data-target="#myModal1">Add New Treatment</button>
			</h1>
			<br/>
		</div>
		<div class="col-md-12">
			<table class="table" id="hospital_table">
				<thead>
					<th>#</th>
					<th>Name</th>
					<th>Description</th>
					<th>Vertical</th>
					<th>Option</th>
				</thead>
				<tbody id="treatment_body">
					
				</tbody>
			</table>
		</div>
	</div>
</div>

<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<form class="form-horizontal" role="form">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
				<h4 class="modal-title">Modify Treatment</h4>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-2 control-label">Name</label>
					<div class="col-sm-10">
						<input type="text" class="form-control" id="mod-name" placeholder="Enter Treatment Name">
					</div>
				</div>
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-2 control-label">Description</label>
					<div class="col-sm-10">
						<textarea name="desription" id="mod-description" class="form-control" rows="5"></textarea>
					</div>
				</div>
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-2 control-label">Vertical</label>
					<div class="col-sm-10">
						<select id="mod-vertical" name="vertical" style="width:100%" class="vertical">
						  	
						</select>
					</div>
				</div>
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-2 control-label">Type</label>
					<div class="col-sm-10">
						<select id="mod-type" name="mod-type" style="width:100%">
						  	<option value="1">Medical</option>
						  	<option value="0">Aurvedic</option>
						</select>
					</div>
				</div>
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-2 control-label">Status</label>
					<div class="col-sm-10">
						<select id="mod-status" name="mod-status" style="width:100%" class="status">
						  	<option value="1">Active</option>
						  	<option value="0">Not Active</option>
						</select>
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<button type="button" id="modBtn" class="btn btn-primary">Save changes</button>
			</div>
			</form>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<form class="form-horizontal" role="form">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
				<h4 class="modal-title">Add Treatment</h4>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-2 control-label">Name</label>
					<div class="col-sm-10">
						<input type="text" class="form-control" id="name" placeholder="Enter Treatment Name">
					</div>
				</div>
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-2 control-label">Description</label>
					<div class="col-sm-10">
						<textarea name="desription" id="description" class="form-control" rows="5"></textarea>
					</div>
				</div>
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-2 control-label">Type</label>
					<div class="col-sm-10">
						<select id="type" name="type" style="width:100%">
						  	<option value="1">Medical</option>
						  	<option value="0">Aurvedic</option>
						</select>
					</div>
				</div>
				<div class="form-group">
					<label for="inputEmail3" class="col-sm-2 control-label">Vertical</label>
					<div class="col-sm-10">
						<select id="vertical" name="vertical" style="width:100%" class="vertical">
						  	
						</select>
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<button type="button" id="saveBtn" class="btn btn-success">Add New</button>
			</div>
			</form>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<script type="text/javascript">
	$(document).ready( function () {
		var newHtml;
		$.ajax({
           	url: 'json/listTreat.php',
           	type: "POST",
           	cache: false,
           	async: false,
           	dataType:"json",
           	success: function(data, textStatus, jqXHR){
           		//console.log(data);
           		if(data.success == true){
           			//console.log(data.data);
           			var i = 1;
           			$.each(data.data, function(index,value){
           				var countries = [];
           				newHtml += '<tr><td>'+i+'</td><td>'+value['name']+'</td><td>'+value['description']+'</td><td>'+value['vertical']+'</td><td><a href="treatment.php?treatment='+value['token']+'">Details</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="#" data-toggle="modal" data-target="#myModal" data-token="'+value['token']+'" class="edit-treatment">Edit</a></td></tr>';
           				i++;
           			});
           			//console.log(newHtml);
           			$('#treatment_body').html(newHtml);
           		}else{
           			newHtml += '<tr><td colspan="6">No Data Found</td></tr>';
           			$('#treatment_body').html(newHtml);
           		}
           	}, 
           	error: function(response, textStatus, jqXHR){
            	console.log(response);
           	}
      	});
		newHtml = '';
		$.ajax({
           	url: 'json/listTreatment.php',
           	type: "POST",
           	cache: false,
           	async: false,
           	dataType:"json",
           	success: function(data, textStatus, jqXHR){
           		if(data.success == true){
           			//console.log(data.data);
           			$.each(data.data, function(index,value){
           				newHtml += '<option value="'+value['token']+'">'+value['name']+'</option>';
           			});
           			//console.log(newHtml);
           			$('#vertical').html(newHtml);
           			$('#mod-vertical').html(newHtml);
           		}else{
           			newHtml += '<option value="">No Vertical Found</option>';
           			$('#vertical').html(newHtml);
           			$('#mod-vertical').html(newHtml);
           		}
           	}, 
           	error: function(response, textStatus, jqXHR){
            	console.log(response);
           	}
      	});

      	$('#saveBtn').off('click').on('click', function(e){
			e.preventDefault();
			$('#message').empty();
			var data = {};	
			data['name'] = $('#name').val();
			data['description'] = $('#description').val();
			data['vertical'] = $('#vertical').val();
			data['type'] = $('#type').val();
			console.log(data);
			var newHtml;
			$.ajax({
	           	url: 'json/addTreat.php',
	           	type: "POST",
	           	cache: false,
	           	async: false,
	           	data: data,
	           	dataType:"json",
	           	success: function(data, textStatus, jqXHR){
	           		//console.log(data);
	           		if(data.success == true){
	           			newHtml = '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>New Treatment is created successfully.</div>';
	           			$('#message').append(newHtml);
	           			$('#myModal1').modal('hide');
	           		}else{
	           			newHtml = '<div class="alert alert-warning"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Treatment is not created, please fill the form properly.</div>';
	           			$('#message').append(newHtml);
	           		}
	           	}, 
	           	error: function(response, textStatus, jqXHR){
	            	newHtml = '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Oopss...Something went terribly wrong please contact RepIndia.</div>';
	           			$('#message').append(newHtml);
	           		console.log(response);
	           	}
          	});
		});

	
		$('.edit-treatment').off('click').on('click', function(e){
			$('#message').empty();
			var data = {};
			data['token'] = $(this).attr('data-token');
			console.log(data);
			$.ajax({
	           	url: 'json/getTreat.php',
	           	type: "POST",
	           	cache: false,
	           	async: false,
	           	data: data,
	           	dataType:"json",
	           	success: function(data, textStatus, jqXHR){
	           		console.log(data);
	           		$('#mod-name').val(data.data.name);
	           		$('#mod-description').val(data.data.description);
	           		$('#mod-vertical').val(data.data.vertical);
	           		$('#mod-status').val(data.data.status);
	           		$('#mod-type').val(data.data.type);
	           	},
	           	error: function(response, textStatus, jqXHR){
	            	console.log(response);
	            	newHtml = '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Oopss...Something went terribly wrong please contact RepIndia.</div>';
	           			$('#message').append(newHtml);
	           	}
          	});

			$('#modBtn').off('click').on('click', function(e){
				e.preventDefault();
				$('#message').empty();
				data['name'] = $('#mod-name').val();
				data['description'] = $('#mod-description').val();
				data['vertical'] = $('#mod-vertical').val();
				data['status'] = $('#mod-status').val();
				data['type'] = $('#mod-type').val();
				console.log(data);
				$.ajax({
		           	url: 'json/updateTreat.php',
		           	type: "POST",
		           	cache: false,
		           	async: false,
		           	data: data,
		           	dataType:"json",
		           	success: function(data, textStatus, jqXHR){
		           		console.log(data);
		           		if(data.success == true){
		           			newHtml = '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Treatment is successfully updated. Please refresh your page.</div>';
		           			$('#message').append(newHtml);
		           			$('#myModal').modal('hide');
		           		}else{
		           			newHtml = '<div class="alert alert-warning"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Treatment is not updated, please fill the form properly.</div>';
		           			$('#message').append(newHtml);
		           		}
		           	},
		           	error: function(response, textStatus, jqXHR){
		            	console.log(response);
		            	newHtml = '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Oopss...Something went terribly wrong please contact RepIndia.</div>';
		           			$('#message').append(newHtml);
		           	}
	          	});
			});
        });

		$('#hospital_table').DataTable();
		/*$("#mod-vertical").select2({
			placeholder: "Select Verticals"
		});
		$("#mod-status").select2();
		$("#vertical").select2({
			placeholder: "Select Verticals"
		});*/
	});
</script>
<?php require_once('footer.php'); ?>