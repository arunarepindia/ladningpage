<?php	
	$vertical = $_POST['vertical'];
	$country = $_POST['country'];
	include_once '../../../apicaller.php';
	$apicaller = new ApiCaller('APP001', '28e336ac6c9423d946ba02d19c6a2632', URL);
	$result = $apicaller->SendRequest(
		array(
			'controller' => 'doctors',
			'action' => 'filterDoctorByVerticalCountry',
			'vertical' => $vertical,
			'country' => $country
		)
	);
	echo json_encode($result);
?>