<?php
	$token = $_POST['token'];
	$name = $_POST['name'];
	$address = $_POST['address'];
	$stateID = $_POST['state'];
	$countryID = $_POST['country'];
	$status = $_POST['status'];

	include_once '../../apicaller.php';
	$apicaller = new ApiCaller('APP001', '28e336ac6c9423d946ba02d19c6a2632', URL);
	$result = $apicaller->SendRequest(
		array(
			'controller' => 'hospitals',
			'action' => 'update',
			'name' => $name,
			'address' => $address,
			'stateID' => $stateID,
			'countryID' => $countryID,
			'status' => $status,
			'token' => $token
		)
	);
	echo json_encode($result);
?>