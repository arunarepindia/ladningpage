<?php
	$countries = $_POST['countries'];
	include_once '../../apicaller.php';
	$apicaller = new ApiCaller('APP001', '28e336ac6c9423d946ba02d19c6a2632', URL);
	$final = array();
	//print_r($countries);
	if(count($countries) > 0){
		foreach($countries as $country){
			$result = $apicaller->SendRequest(
				array(
					'controller' => 'doctors',
					'action' => 'list',
					'country' => $country,
					'by' => 'country'
				)
			);
			array_push($final, $result);
		}
	}
	//print_r($final);
	echo json_encode($final);
?>