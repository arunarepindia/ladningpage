<?php
	$name = $_POST['name'];
	$specialization = $_POST['specialization'];
	$qualification = $_POST['qualification'];
	$location = $_POST['hospital'];
	$fellow = $_POST['fellowship'];
	$area = $_POST['area'];
	$work = $_POST['work'];
	$more = $_POST['more'];
	$type = $_POST['type'];

	include_once '../../apicaller.php';
	$apicaller = new ApiCaller('APP001', '28e336ac6c9423d946ba02d19c6a2632', URL);
	$result = $apicaller->SendRequest(
		array(
			'controller' => 'doctors',
			'action' => 'add',
			'name' => $name,
			'specialization' => $specialization,
			'locationID' => $location,
			'qualification' => $qualification,
			'area' => $area,
			'work' => $work,
			'fellow' => $fellow,
			'type' => $type,
			'more' => $more
		)
	);
	echo json_encode($result);
?>