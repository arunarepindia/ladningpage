<?php
	$name = $_POST['name'];
	$code = isset($_POST['code'])?$_POST['code']:NULL;
	$countryID = $_POST['country'];
	$status = isset($_POST['status'])?$_POST['status']:1;

	include_once '../../apicaller.php';
	$apicaller = new ApiCaller('APP001', '28e336ac6c9423d946ba02d19c6a2632', URL);
	$result = $apicaller->SendRequest(
		array(
			'controller' => 'states',
			'action' => 'add',
			'name' => $name,
			'code' => $code,
			'countryID' => $countryID,
			'status' => $status
		)
	);
	echo json_encode($result);
?>