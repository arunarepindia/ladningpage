<?php
	$name = $_POST['name'];
	$specialization = $_POST['specialization'];
	$qualification = $_POST['qualification'];
	$location = $_POST['hospital'];
	$fellow = $_POST['fellowship'];
	$area = $_POST['area'];
	$work = $_POST['work'];
	$more = $_POST['more'];
	$type = $_POST['type'];
	$status = $_POST['status'];
	$token= $_POST['token'];
	
	include_once '../../apicaller.php';
	$apicaller = new ApiCaller('APP001', '28e336ac6c9423d946ba02d19c6a2632', URL);
	$result = $apicaller->SendRequest(
		array(
			'controller' => 'doctors',
			'action' => 'update',
			'name' => $name,
			'specialization' => $specialization,
			'locationID' => $location,
			'qualification' => $qualification,
			'area' => $area,
			'fellow' => $fellow,
			'type' => $type,
			'work' => $work,
			'more' => $more,
			'status' => $status,
			'token' => $token
		)
	);
	echo json_encode($result);
?>