<?php
	$name = $_POST['name'];
	$address = $_POST['address'];
	$stateID = $_POST['stateID'];
	$countryID = $_POST['countryID'];

	include_once '../../apicaller.php';
	$apicaller = new ApiCaller('APP001', '28e336ac6c9423d946ba02d19c6a2632', URL);
	$result = $apicaller->SendRequest(
		array(
			'controller' => 'hospitals',
			'action' => 'add',
			'name' => $name,
			'address' => $address,
			'stateID' => $stateID,
			'countryID' => $countryID
		)
	);
	echo json_encode($result);
?>