<?php
	$name = $_POST['name'];
	$code = isset($_POST['code'])?$_POST['code']:NULL;
	$description = isset($_POST['description'])?$_POST['description']:NULL;
	$token = $_POST['token'];
	$status = $_POST['status'];

	include_once '../../apicaller.php';
	$apicaller = new ApiCaller('APP001', '28e336ac6c9423d946ba02d19c6a2632', URL);
	$result = $apicaller->SendRequest(
		array(
			'controller' => 'treatment',
			'action' => 'update',
			'name' => $name,
			'code' => $code,
			'description' => $description,
			'status' => $status,
			'token' => $token
		)
	);
	echo json_encode($result);
?>