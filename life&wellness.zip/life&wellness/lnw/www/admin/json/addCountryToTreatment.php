<?php
	$treatment = $_POST['treatment'];
	$country = $_POST['country'];

	include_once '../../apicaller.php';
	$apicaller = new ApiCaller('APP001', '28e336ac6c9423d946ba02d19c6a2632', URL);
	$result = $apicaller->SendRequest(
		array(
			'controller' => 'treatment',
			'action' => 'addCountryToTreatment',
			'treatment' => $treatment,
			'country' => $country
		)
	);
	echo json_encode($result);
?>