<?php
	class Countries{
		private $db;
		private $_params;
		public function __construct($params){
			try{
				require_once '../../lnw/services/db_config.php';
				$this->db = new PDO ("mysql:host=$hostname;port=3306;dbname=$dbname","$username","$pw");
				$this->_params = $params;
			} catch (PDOException $e) {
				echo "Failed to get DB handle: " . $e->getMessage() . "\n";
				exit;
			}
		}

		public function getAction(){
			$token = $this->_params['token'];
			$stmt = $this->db->prepare("SELECT id, name, code, token, status FROM countries WHERE token = :token");
			$stmt->bindValue(':token', $token, PDO::PARAM_INT);
			$stmt->execute();
			$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
			return $rows;
		}

		public function listAction(){
			$pagination = $this->_params['pagination'];
			if($pagination == true){
				$page = $this->_params['page'];
				$offset = $this->_params['offset'];
			}
			if($pagination == true){
				$stmt = $this->db->prepare("SELECT id, name, code, token, status FROM countries WHERE status = 1 ORDER BY name LIMIT :offset, :limit");
				$second = $page * $offset;
				$first = $second - $offset;
				$stmt->bindValue(':offset', $first, PDO::PARAM_INT);
				$stmt->bindValue(':limit', $second, PDO::PARAM_INT);
			}else{
				$stmt = $this->db->prepare("SELECT id, name, code, token, status FROM countries ORDER BY name");
			}
			$stmt->execute();
			$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
			return $rows;
		}

		public function addAction(){
			$name = $this->_params['name'];
			$code = $this->_params['code'];
			$status = $this->_params['status'];
			$stmt = $this->db->prepare("INSERT into countries(name, code, status) VALUES(:name, :code, :status)");
			$stmt->bindValue(':name', $name, PDO::PARAM_STR);
			$stmt->bindValue(':code', $code, PDO::PARAM_STR);
			$stmt->bindValue(':status', $status, PDO::PARAM_INT);
			$stmt->execute();
			$lastID = $this->db->lastInsertId();
			$stmt = $this->db->prepare("UPDATE countries SET token = :token WHERE id = :id");
			$stmt->bindValue(':token', md5($lastID), PDO::PARAM_STR);
			$stmt->bindValue(':id', $lastID, PDO::PARAM_INT);
			$stmt->execute();
			return array('token' => md5($lastID));
		}

		public function updateAction(){
			$name = $this->_params['name'];
			$code = $this->_params['code'];
			$status = $this->_params['status'];
			$token = $this->_params['token'];
			$stmt = $this->db->prepare("UPDATE countries SET name = :name, code = :code, status = :status WHERE token = :token");
			$stmt->bindValue(':name', $name, PDO::PARAM_STR);
			$stmt->bindValue(':code', $code, PDO::PARAM_STR);
			$stmt->bindValue(':status', $status, PDO::PARAM_INT);
			$stmt->bindValue(':token', $token, PDO::PARAM_STR);
			$stmt->execute();
			return ;
		}

		public function filterbytypeAction(){
			$type = $this->_params['type'];
			$stmt = $this->db->prepare("SELECT country.name as name, country.token as token FROM countries as country INNER JOIN hospitals as h ON h.countryID = country.token INNER JOIN doctors as d ON d.location = h.token WHERE d.type = :type");
			$stmt->bindValue(':type', $type, PDO::PARAM_INT);
			$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
			return $rows;
		}

		public function filterbytreatment(){
			$treatment = $this->_params['treatment'];
			$stmt = $this->db->prepare("SELECT c.name, c.token FROM countries as c INNER JOIN treatment_country as tc ON tc.countryID = c.token WHERE tc.treatmentID = :treatment");
			$stmt->bindValue(':treatment', $treatment, PDO::PARAM_INT);
			$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
			return $rows;
		}
	}
?>