<?php
	class Doctors{
		private $db;
		private $_params;
		public function __construct($params){
			try{
				require_once '../../lnw/services/db_config.php';
				$this->db = new PDO ("mysql:host=$hostname;port=3306;dbname=$dbname","$username","$pw");
				$this->_params = $params;
			} catch (PDOException $e) {
				echo "Failed to get DB handle: " . $e->getMessage() . "\n";
				exit;
			}
		}

		public function getAction(){
			$token = $this->_params['token'];
			$stmt = $this->db->prepare("SELECT doctor.id, doctor.name, doctor.specialization, doctor.qualification, doctor.area, doctor.work, doctor.more, doctor.fellow, doctor.type, doctor.location, hospital.token as hospital, state.token as state, country.token as country, doctor.token, doctor.status FROM doctors as doctor INNER JOIN hospitals as hospital ON hospital.token = doctor.location INNER JOIN states as state ON state.token = hospital.stateID INNER JOIN countries as country ON country.token = hospital.countryID WHERE doctor.token = :token");
			$stmt->bindValue(':token', $token, PDO::PARAM_STR);
			$stmt->execute();
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			return $row;
		}

		public function allAction(){
			$stmt = $this->db->prepare("SELECT doctor.id, doctor.name, doctor.specialization, doctor.qualification, doctor.location, hospital.name as hospital, state.name as state, country.name as country, doctor.token FROM doctors as doctor INNER JOIN hospitals as hospital ON hospital.token = doctor.location INNER JOIN states as state ON state.token = hospital.stateID INNER JOIN countries as country ON country.token = hospital.countryID ORDER BY hospital.name, doctor.name");
			$stmt->execute();
			$row = $stmt->fetchAll(PDO::FETCH_ASSOC);
			return $row;
		}

		public function listAction(){
			$by = $this->_params['by'];
			$country = $this->_params['country'];
			if($by == 'both'){
				$country = $this->_params['country'];
				$treatment = $this->_params['treatment'];
				$stmt = $this->db->prepare("SELECT doctor.id, doctor.name, doctor.location, hospital.name, state.name, country.name, doctor.token, td.treatmentID, td.doctorID, treatment.name FROM doctors as doctor INNER JOIN hospitals as hospital ON hospital.token = doctor.location INNER JOIN states as state ON state.token = hospital.stateID INNER JOIN countries as country ON country.token = hospital.countryID INNER JOIN treatments as treatment WHERE treatment.token = :treatment WHERE country.token = :country AND treatment.token as :treatment AND doctor.status = 1");
				$stmt->bindValue(':country', $country, PDO::PARAM_STR);
				$stmt->bindValue(':treatment', $treatment, PDO::PARAM_STR);
			}
			else if($by == 'country'){
				$country = $this->_params['country'];
				$stmt = $this->db->prepare("SELECT doctor.id, doctor.name, doctor.location, hospital.name as hospital, state.name as state, country.name as country, doctor.token FROM doctors as doctor INNER JOIN hospitals as hospital ON hospital.token = doctor.location INNER JOIN states as state ON state.token = hospital.stateID INNER JOIN countries as country ON country.token = hospital.countryID WHERE country.token = :country AND doctor.status = 1");
				$stmt->bindValue(':country', $country, PDO::PARAM_STR);
			}
			else{
				$treatment = $this->_params['treatment'];
				$stmt = $this->db->prepare("SELECT doctor.id, doctor.name, doctor.token, td.treatmentID, td.doctorID, treatment.name FROM doctors as doctor INNER JOIN treatment_doctor as td ON td.doctorID = doctor.token INNER JOIN treatments as treatment WHERE treatment.token = :treatment AND doctor.status = 1");
				$stmt->bindValue(':treatment', $treatment, PDO::PARAM_STR);
			}
			$stmt->execute();
			$row = $stmt->fetchAll(PDO::FETCH_ASSOC);
			return $row;
		}

		public function addAction(){
			$name = $this->_params['name'];
			$specialization = $this->_params['specialization'];
			$location = $this->_params['locationID'];
			$qualification = $this->_params['qualification'];
			$area = $this->_params['area'];
			$fellow = $this->_params['fellow'];
			$work = $this->_params['work'];
			$more = $this->_params['more'];
			$type = $this->_params['type'];

			$stmt = $this->db->prepare("INSERT INTO doctors(name, specialization, location, qualification, area, fellow, work, more, type) VALUES(:name, :specialization, :location, :qualification, :area, :fellow, :work, :more, :type)");
			$stmt->bindValue(':name', $name, PDO::PARAM_STR);
			$stmt->bindValue(':specialization', $specialization, PDO::PARAM_STR);
			$stmt->bindValue(':location', $location, PDO::PARAM_STR);
			$stmt->bindValue(':qualification', $qualification, PDO::PARAM_STR);
			$stmt->bindValue(':area', $area, PDO::PARAM_STR);
			$stmt->bindValue(':work', $work, PDO::PARAM_STR);
			$stmt->bindValue(':fellow', $fellow, PDO::PARAM_STR);
			$stmt->bindValue(':more', $more, PDO::PARAM_STR);
			$stmt->bindValue(':type', $type, PDO::PARAM_INT);
			$stmt->execute();
			$lastID = $this->db->lastInsertId();
			$stmt = $this->db->prepare("UPDATE doctors SET token = :token WHERE id = :id");
			$stmt->bindValue(':token', md5($lastID), PDO::PARAM_STR);
			$stmt->bindValue(':id', $lastID, PDO::PARAM_INT);
			$stmt->execute();
			return array('token' => md5($lastID));
		}

		public function updateAction(){
			$token = $this->_params['token'];
			$name = $this->_params['name'];
			$specialization = $this->_params['specialization'];
			$location = $this->_params['locationID'];
			$qualification = $this->_params['qualification'];
			$area = $this->_params['area'];
			$work = $this->_params['work'];
			$fellow = $this->_params['fellow'];
			$more = $this->_params['more'];	
			$type = $this->_params['type'];	
			$status = $this->_params['status'];
			$stmt = $this->db->prepare("UPDATE doctors SET name = :name, specialization = :specialization, location = :location, qualification = :qualification, area = :area, fellow = :fellow, work = :work, more = :more, type = :type, status = :status WHERE token = :token");
			$stmt->bindValue(':name', $name, PDO::PARAM_STR);
			$stmt->bindValue(':specialization', $specialization, PDO::PARAM_STR);
			$stmt->bindValue(':location', $location, PDO::PARAM_STR);
			$stmt->bindValue(':qualification', $qualification, PDO::PARAM_STR);
			$stmt->bindValue(':area', $area, PDO::PARAM_STR);
			$stmt->bindValue(':fellow', $fellow, PDO::PARAM_STR);
			$stmt->bindValue(':work', $work, PDO::PARAM_STR);
			$stmt->bindValue(':more', $more, PDO::PARAM_STR);
			$stmt->bindValue(':type', $type, PDO::PARAM_INT);
			$stmt->bindValue(':status', $status, PDO::PARAM_INT);
			$stmt->bindValue(':token', $token, PDO::PARAM_STR);
			$stmt->execute();
			return ;
		}

		public function filterbytreatmentAction(){
			$treatment = $this->_params['treatment'];
			$stmt = $this->db->prepare("SELECT * FROM doctors INNER JOIN treatment_doctors as td ON doctors.token = td.doctorID WHERE td.treatmentID = :treatment");
			$stmt->bindValue(':treatment', $treatment, PDO::PARAM_STR);
			$stmt->execute();
			$row = $stmt->fetchAll(PDO::FETCH_ASSOC);
			return $row;
		}

		public function filterDoctorByVerticalCountryAction(){
			$treatment = $this->_params['vertical'];
			$country = $this->_params['country'];
			
			$stmt = $this->db->prepare("SELECT distinct d.id, d.name, d.specialization, qualification, area, fellow, work, more, type, picture, d.token, s.name as state, c.name as country FROM doctors as d INNER JOIN treatment_doctor as td ON td.doctorID = d.token INNER JOIN treatment_country as tc ON tc.treatmentID = td.treatmentID INNER JOIN hospitals as h ON h.token = d.location INNER JOIN countries as c ON c.token = h.countryID INNER JOIN states as s ON s.token = h.stateID WHERE td.treatmentID = :treatment AND d.status = 1");
			$stmt->bindValue(':treatment', $treatment, PDO::PARAM_STR);
			$stmt->execute();
			$row['doctors'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
			//print_r($row);
			return $row;
		}

	}
?>