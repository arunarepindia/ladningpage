<?php
	class Treat{
		private $db;
		private $_params;
		public function __construct($params){
			try{
				require_once '../../lnw/services/db_config.php';
				$this->db = new PDO ("mysql:host=$hostname;port=3306;dbname=$dbname","$username","$pw");
				$this->_params = $params;
			} catch (PDOException $e) {
				echo "Failed to get DB handle: " . $e->getMessage() . "\n";
				exit;
			}
		}

		public function getAction(){
			$token = $this->_params['token'];
			$stmt = $this->db->prepare("SELECT t.name, t.description, t.type, t.verticalID as vertical, t.status, t.token FROM treatment as t WHERE t.token = :token");
			$stmt->bindValue(':token', $token, PDO::PARAM_INT);
			$stmt->execute();
			$rows = $stmt->fetch(PDO::FETCH_ASSOC);
			return $rows;
		}

		public function detailAction(){
			$token = $this->_params['token'];
			$stmt = $this->db->prepare("SELECT t.name, t.token FROM treatment as t WHERE t.token = :token");
			$stmt->bindValue(':token', $token, PDO::PARAM_INT);
			$stmt->execute();
			$rows["treatment"] = $stmt->fetchAll(PDO::FETCH_ASSOC);

			$stmt = $this->db->prepare("SELECT c.name, c.token, tc.price FROM countries as c INNER JOIN treat_country as tc ON tc.countryID = c.token WHERE tc.treatmentID = :token");
			$stmt->bindValue(':token', $token, PDO::PARAM_INT);
			$stmt->execute();
			$rows["countries"] = $stmt->fetchAll(PDO::FETCH_ASSOC);
			return $rows;
		}

		public function listAction(){
			$stmt = $this->db->prepare("SELECT t.name, t.description, t.token, v.name as vertical FROM treatment as t INNER JOIN treatments as v ON v.token = t.verticalID");
			$stmt->execute();
			$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
			return $rows;
		}

		public function addAction(){
			$name = $this->_params['name'];
			$description = $this->_params['description'];
			$vertical = $this->_params['vertical'];
			$type = $this->_params['type'];
			$stmt = $this->db->prepare("INSERT into treatment(name, description, type, verticalID) VALUES(:name, :description, :type, :vertical)");
			$stmt->bindValue(':name', $name, PDO::PARAM_STR);
			$stmt->bindValue(':description', $description, PDO::PARAM_STR);
			$stmt->bindValue(':type', $type, PDO::PARAM_INT);
			$stmt->bindValue(':vertical', $vertical, PDO::PARAM_STR);
			$stmt->bindValue(':type', $type, PDO::PARAM_INT);
			$stmt->execute();

			$lastID = $this->db->lastInsertId();
			$stmt = $this->db->prepare("UPDATE treatment SET token = :token WHERE id = :id");
			$stmt->bindValue(':token', md5($lastID), PDO::PARAM_STR);
			$stmt->bindValue(':id', $lastID, PDO::PARAM_INT);
			$stmt->execute();
			return array('token' => md5($lastID));
		}

		public function addCountryAction(){
			$treatment = $this->_params['treatment'];
			$country = $this->_params['country'];
			$price = $this->_params['price'];
			$stmt = $this->db->prepare("INSERT into treat_country(treatmentID, countryID, price) VALUES(:treatment, :country, :price)");
			$stmt->bindValue(':treatment', $treatment, PDO::PARAM_STR);
			$stmt->bindValue(':country', $country, PDO::PARAM_STR);
			$stmt->bindValue(':price', $price, PDO::PARAM_STR);
			$stmt->execute();
			return;
		}

		public function removeCountryAction(){
			$treatment = $this->_params['treatment'];
			$country = $this->_params['country'];
			$stmt = $this->db->prepare("DELETE FROM treat_country WHERE treatmentID = :treatment AND countryID = :country");
			$stmt->bindValue(':treatment', $treatment, PDO::PARAM_STR);
			$stmt->bindValue(':country', $country, PDO::PARAM_STR);
			$stmt->execute();	
			return;
		}

		public function updateCountryAction(){
			$treatment = $this->_params['token'];
			$country = $this->_params['country'];
			$price = $this->_params['price'];
			$stmt = $this->db->prepare("UPDATE treat_country SET price = :price WHERE treatmentID = :treatment AND countryID = :country");
			$stmt->bindValue(':treatment', $treatment, PDO::PARAM_STR);
			$stmt->bindValue(':country', $country, PDO::PARAM_STR);
			$stmt->execute();
			return;
		}

		public function updateAction(){
			$name = $this->_params['name'];
			$description = $this->_params['description'];
			$vertical = $this->_params['vertical'];
			$type = $this->_params['type'];
			$status = $this->_params['status'];
			$token = $this->_params['token'];
			$stmt = $this->db->prepare("UPDATE treatment SET name = :name, description = :description, type = :type, verticalID = :vertical, status = :status WHERE token = :token");
			$stmt->bindValue(':name', $name, PDO::PARAM_STR);
			$stmt->bindValue(':description', $description, PDO::PARAM_STR);
			$stmt->bindValue(':vertical', $vertical, PDO::PARAM_STR);
			$stmt->bindValue(':type', $type, PDO::PARAM_INT);
			$stmt->bindValue(':status', $status, PDO::PARAM_INT);
			$stmt->bindValue(':token', $token, PDO::PARAM_STR);
			$stmt->execute();
			return'ok';
		}

		public function filterbyverticalAction(){
			$vertical = $this->_params['vertical'];
			$type = $this->_params['type'];
			$stmt = $this->db->prepare("SELECT c.name as country, c.token as countryID FROM treatment as t INNER JOIN treat_country as tc ON tc.treatmentID = t.token INNER JOIN countries as c ON c.token = tc.countryID WHERE t.verticalID = :vertical GROUP BY c.name ORDER BY c.name, t.name");
			$stmt->bindValue(':vertical', $vertical, PDO::PARAM_STR);
			$stmt->execute();
			$rows["treatments"]["countries"] = $stmt->fetchAll(PDO::FETCH_ASSOC);
			foreach($rows["treatments"]["countries"] as &$country){
				$stmt = $this->db->prepare("SELECT t.name, t.token, tc.price FROM treatment as t INNER JOIN treat_country as tc ON tc.treatmentID = t.token WHERE tc.countryID = :country AND t.verticalID = :vertical AND t.type = :type");
				$stmt->bindValue(':country', $country["countryID"], PDO::PARAM_STR);
				$stmt->bindValue(':vertical', $vertical, PDO::PARAM_STR);
				$stmt->bindValue(':type', $type, PDO::PARAM_INT);
				$stmt->execute();
				$country["treatments"] = $stmt->fetchAll(PDO::FETCH_ASSOC);
			}
			return $rows;
		}
	}
?>