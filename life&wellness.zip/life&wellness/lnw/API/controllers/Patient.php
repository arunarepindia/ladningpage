<?php
	class Patients{
		private $db;
		private $_params;
		public function __construct($params){
			try{
				require_once '../../lnw/services/db_config.php';
				$this->db = new PDO ("mysql:host=$hostname;port=3306;dbname=$dbname","$username","$pw");
				$this->_params = $params;
			} catch (PDOException $e) {
				echo "Failed to get DB handle: " . $e->getMessage() . "\n";
				exit;
			}
		}

		public function getAction(){
			$token = $this->_params['token'];
			$stmt = $this->db->prepare('SELECT patient.id, patient.name, patient.email, patient.number, patient.stateID, state.name, patient.countryID, country.name, patient.referno, patient.token, patient.status FROM patients as patient INNER JOIN states as state ON state.token = patient.stateID INNER JOIN countries as country ON country.token = patient.countryID WHERE patient.token = :token AND patient.status = 1');
			$stmt->bindValue(':token', $token, PDO::PARAM_STR);
			$stmt->execute();
			$row = $stmt->fetch();

			$stmt = $this->db->prepare('SELECT id, messages, token, created_at FROM patient_messages WHERE userID = :token');
			$stmt->bindValue(':token', $row['token'], PDO::PARAM_STR);
			$stmt->execute();
			$row['messages'] = $stmt->fetchAll();

			$stmt = $this->db->prepare('SELECT id, filename, created_at FROM patient_files WHERE userID = :token');
			$stmt->bindValue(':token', $row['token'], PDO::PARAM_STR);
			$stmt->execute();
			$row['files'] = $stmt->fetchAll();

			return $row;
		}

		public function allAction(){
			$stmt = $this->db->prepare('SELECT patient.id, patient.name, patient.email, patient.number, patient.stateID, state.name, patient.countryID, country.name, patient.referno, patient.token, patient.status FROM patients as patient INNER JOIN states as state ON state.token = patient.stateID INNER JOIN countries as country ON country.token = patient.countryID WHERE patient.status = 1');
			$stmt->execute();
			$row = $stmt->fetchAll();
		}

		public function addAction(){
			$name = $this->_params['name'];
			$email = $this->_params['email'];
			$number = $this->_params['phone'];
			$stateID = $this->_params['stateID'];
			$countryID = $this->_params['countryID'];
			$message = isset($this->_params['message'])?$this->_params['message']:'';
			$files = isset($this->_params['files'])?$this->_params['files']:'';
			
			$stmt = $this->db->prepare("INSERT INTO patients(name, email, number, stateID, countryID) VALUES(:name, :email, :number, :stateID, :countryID)");
			$stmt->bindValue(':name', $row['name'], PDO::PARAM_STR);
			$stmt->bindValue(':email', $row['email'], PDO::PARAM_STR);
			$stmt->bindValue(':number', $row['number'], PDO::PARAM_STR);
			$stmt->bindValue(':stateID', $row['stateID'], PDO::PARAM_STR);
			$stmt->bindValue(':countryID', $row['countryID'], PDO::PARAM_STR);
			$stmt->execute();
			
			$lastID = $this->db->lastInsertId();
			$stmt = $this->db->prepare("UPDATE patients SET token = :token WHERE id = :id");
			$stmt->bindValue(':token', md5($lastID), PDO::PARAM_STR);
			$stmt->bindValue(':id', $lastID, PDO::PARAM_INT);
			$stmt->execute();

			return array('token' => md5($lastID));
		}

	}
?>