<?php
	class States{
		private $db;
		private $_params;
		public function __construct($params){
			try{
				require_once '../../lnw/services/db_config.php';
				$this->db = new PDO ("mysql:host=$hostname;port=3306;dbname=$dbname","$username","$pw");
				$this->_params = $params;
			} catch (PDOException $e) {
				echo "Failed to get DB handle: " . $e->getMessage() . "\n";
				exit;
			}
		}

		public function getAction(){
			$token = $this->_params['token'];
			$stmt = $this->db->prepare("SELECT state.id, state.name, state.code, country.token as countryID, country.name as country, state.status FROM states as state INNER JOIN countries as country ON state.countryID = country.token WHERE state.token = :token AND state.status = 1");
			$stmt->bindValue(':token', $token, PDO::PARAM_STR);
			$stmt->execute();
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			//$stmt->debugDumpParams();
			return $row;
		}

		public function allAction(){
			$stmt = $this->db->prepare("SELECT state.id, state.name, state.code, country.name as country, state.status, state.token FROM states as state INNER JOIN countries as country ON state.countryID = country.token ORDER BY state.name");
			$stmt->execute();
			$row = $stmt->fetchAll(PDO::FETCH_ASSOC);
			//$stmt->debugDumpParams();
			return $row;
		}

		public function listAction(){
			$country = $this->_params['country'];
			$stmt = $this->db->prepare("SELECT state.id, state.name, state.code, country.name as country, state.status, state.token FROM states as state INNER JOIN countries as country ON state.countryID = country.token WHERE state.countryID = :token AND state.status = 1 ORDER BY state.name");
			$stmt->bindValue(':token', $country, PDO::PARAM_STR);
			$stmt->execute();
			$row = $stmt->fetchAll(PDO::FETCH_ASSOC);
			//$stmt->debugDumpParams();
			return $row;
		}

		public function addAction(){
			$name = $this->_params['name'];
			$code = $this->_params['code'];
			$countryID = $this->_params['countryID'];
			$status = $this->_params['status'];
			$stmt = $this->db->prepare("INSERT into states(name, code, countryID, status) VALUES(:name, :code, :countryID, :status)");
			$stmt->bindValue(':name', $name, PDO::PARAM_STR);
			$stmt->bindValue(':code', $code, PDO::PARAM_STR);
			$stmt->bindValue(':countryID', $countryID, PDO::PARAM_STR);
			$stmt->bindValue(':status', $status, PDO::PARAM_INT);
			$stmt->execute();
			$lastID = $this->db->lastInsertId();
			$stmt = $this->db->prepare("UPDATE states SET token = :token WHERE id = :id");
			$stmt->bindValue(':token', md5($lastID), PDO::PARAM_STR);
			$stmt->bindValue(':id', $lastID, PDO::PARAM_INT);
			$stmt->execute();
			return array('token' => md5($lastID));
		}

		public function updateAction(){
			$name = $this->_params['name'];
			$code = $this->_params['code'];
			$countryID = $this->_params['countryID'];
			$status = $this->_params['status'];
			$token = $this->_params['token'];
			$stmt = $this->db->prepare("UPDATE states SET name = :name, code = :code, countryID = :countryID, status = :status WHERE token = :token");
			$stmt->bindValue(':name', $name, PDO::PARAM_STR);
			$stmt->bindValue(':code', $code, PDO::PARAM_STR);
			$stmt->bindValue(':countryID', $countryID, PDO::PARAM_STR);
			$stmt->bindValue(':status', $status, PDO::PARAM_INT);
			$stmt->bindValue(':token', $token, PDO::PARAM_STR);
			$stmt->execute();
			return ;
		}

	}
?>