<?php
	class Treatment{
		private $db;
		private $_params;
		public function __construct($params){
			try{
				require_once '../../lnw/services/db_config.php';
				$this->db = new PDO ("mysql:host=$hostname;port=3306;dbname=$dbname","$username","$pw");
				$this->_params = $params;
			} catch (PDOException $e) {
				echo "Failed to get DB handle: " . $e->getMessage() . "\n";
				exit;
			}
		}

		public function getAction(){
			$token = $this->_params['token'];
			$stmt = $this->db->prepare("SELECT name, code, description, token, status FROM treatments WHERE token = :token ORDER BY name");
			$stmt->bindValue(':token', $token, PDO::PARAM_STR);
			$stmt->execute();
			$row = $stmt->fetch(PDO::FETCH_ASSOC);

			$stmt = $this->db->prepare("SELECT c.id, c.name, c.code, c.token, tc.treatmentID, tc.countryID FROM countries as c INNER JOIN treatment_country as tc ON tc.countryID = c.token WHERE tc.treatmentID = :token");
			$stmt->bindValue(':token', $row['token'], PDO::PARAM_STR);
			$stmt->execute();
			$row['countries'] = $stmt->fetchAll(PDO::FETCH_ASSOC);

			$stmt = $this->db->prepare("SELECT d.id, d.name, d.token, td.treatmentID, td.doctorID FROM doctors as d INNER JOIN treatment_doctor as td ON td.doctorID = d.token WHERE td.treatmentID = :token");
			$stmt->bindValue(':token', $row['token'], PDO::PARAM_STR);
			$stmt->execute();
			$row['doctors'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
			//$stmt->debugDumpParams();
			return $row;
		}

		public function allAction(){
			$stmt = $this->db->prepare("SELECT name, code, description, token FROM treatments ORDER BY name");
			$stmt->execute();
			$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
			/*if(count($rows) > 0){
				foreach($rows as &$row){
					$stmt = $this->db->prepare("SELECT c.id, c.name, c.code, c.token, tc.treatmentID, tc.countryID FROM countries as c INNER JOIN treatment_country as tc ON tc.countryID = c.token WHERE tc.treatmentID = :token");
					$stmt->bindValue(':token', $row['token'], PDO::PARAM_STR);
					$stmt->execute();
					$row['countries'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
				}
			}*/
			//$stmt->debugDumpParams();
			return $rows;
		}

		//list all treatment by country
		public function listAction(){
			$country = $this->_params['country'];
			$stmt = $this->db->prepare("SELECT distinct treatment.name, treatment.token FROM treatments as treatment INNER JOIN treatment_country as tc ON tc.treatmentID = treatment.token INNER JOIN countries as country ON country.token = tc.countryID WHERE country.token = :token AND treatment.status = 1");
			$stmt->bindValue(':token', $country, PDO::PARAM_STR);
			$stmt->execute();
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			//$stmt->debugDumpParams();
			return $row;
		}

		public function filterbytypecountryAction(){
			$type = $this->_params["type"];
			$country = $this->_params['country'];
			$stmt = $this->db->prepare("SELECT distinct t.name as name, t.token as token FROM treatments as t INNER JOIN treatment_country as tc ON t.token = tc.treatmentID INNER JOIN treatment_doctor as td ON td.treatmentID = tc.treatmentID INNER JOIN doctors as d ON d.token = td.doctorID WHERE d.type = :type AND tc.countryID = :country");
			$stmt->bindValue(':type', $type, PDO::PARAM_INT);
			$stmt->bindValue(':country', $country, PDO::PARAM_STR);
			$stmt->execute();
			$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
			return $rows;
		}

		public function addAction(){
			$name = $this->_params['name'];
			$code = $this->_params['code'];
			$description = $this->_params['description'];
			$stmt = $this->db->prepare("INSERT into treatments(name, code, description, status) VALUES(:name, :code, :description, :status)");
			$stmt->bindValue(':name', $name, PDO::PARAM_STR);
			$stmt->bindValue(':code', $code, PDO::PARAM_STR);
			$stmt->bindValue(':description', $description, PDO::PARAM_STR);
			$stmt->bindValue(':status', 1, PDO::PARAM_INT);
			$stmt->execute();
			$lastID = $this->db->lastInsertId();
			$stmt = $this->db->prepare("UPDATE treatments SET token = :token WHERE id = :id");
			$stmt->bindValue(':token', md5($lastID), PDO::PARAM_STR);
			$stmt->bindValue(':id', $lastID, PDO::PARAM_INT);
			$stmt->execute();
			return array('token' => md5($lastID));
		}

		public function updateAction(){
			$name = $this->_params['name'];
			$code = $this->_params['code'];
			$description = $this->_params['description'];
			$status = $this->_params['status'];
			$token = $this->_params['token'];
			$stmt = $this->db->prepare("UPDATE treatments set name = :name, code = :code, description = :description, status = :status WHERE token = :token");
			$stmt->bindValue(':name', $name, PDO::PARAM_STR);
			$stmt->bindValue(':code', $code, PDO::PARAM_STR);
			$stmt->bindValue(':description', $description, PDO::PARAM_STR);
			$stmt->bindValue(':status', $status, PDO::PARAM_INT);
			$stmt->bindValue(':token', $token, PDO::PARAM_STR);
			$stmt->execute();
			return '';
		}

		public function priceAction(){
			$price = $this->_params['price'];
			$country = $this->_params['countryID'];
			$treatment = $this->_params['treatmentID'];
			$stmt = $this->db->prepare("UPDATE treatment_country set price = :price WHERE countryID = :country AND treatmentID = :treatment");
			$stmt->bindValue(':price', $price, PDO::PARAM_STR);
			$stmt->bindValue(':country', $country, PDO::PARAM_STR);
			$stmt->bindValue(':treatment', $treatment, PDO::PARAM_STR);
		}

		public function filterbytypeAction() {
			$type = $this->_params['type'];
			$stmt = $this->db->prepare("SELECT distinct t.name, t.token FROM treatments as t INNER JOIN treatment_doctor as td ON td.treatmentID = t.token INNER JOIN doctors as d ON d.token = td.doctorID WHERE d.type = :type");
			$stmt->bindValue(':price', $price, PDO::PARAM_INT);
			$stmt->execute();
			$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
			return $rows;
		}

		public function detailAction(){
			$treatment = $this->_params['treatment'];
			$stmt = $this->db->prepare("SELECT distinct c.name, c.token FROM countries as c INNER JOIN treatment_country as tc ON tc.countryID = c.token WHERE tc.treatmentID = :treatment");
			$stmt->bindValue(':treatment', $treatment, PDO::PARAM_STR);
			$stmt->execute();
			$rows['countries'] = $stmt->fetchAll(PDO::FETCH_ASSOC);

			$stmt = $this->db->prepare("SELECT distinct d.name, d.token FROM doctors as d INNER JOIN treatment_doctor as td ON td.doctorID = d.token WHERE td.treatmentID = :treatment");
			$stmt->bindValue(':treatment', $treatment, PDO::PARAM_STR);
			$stmt->execute();
			$rows['doctors'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
			
			$stmt = $this->db->prepare("SELECT name, token FROM treatments WHERE token = :treatment");
			$stmt->bindValue(':treatment', $treatment, PDO::PARAM_STR);
			$stmt->execute();
			$rows['info'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
			return $rows;
		}

		public function addCountryToTreatmentAction(){
			$treatment = $this->_params['treatment'];
			$country = $this->_params['country'];
			$stmt = $this->db->prepare("INSERT INTO treatment_country(treatmentID, countryID) VALUES(:treatment, :country)");
			$stmt->bindValue(':treatment', $treatment, PDO::PARAM_STR);
			$stmt->bindValue(':country', $country, PDO::PARAM_STR);
			$stmt->execute();
			return ;
		}

		public function addDoctorToTreatmentAction(){
			$treatment = $this->_params['treatment'];
			$doctor = $this->_params['doctor'];
			$stmt = $this->db->prepare("INSERT INTO treatment_doctor(treatmentID, doctorID) VALUES(:treatment, :doctor)");
			$stmt->bindValue(':treatment', $treatment, PDO::PARAM_STR);
			$stmt->bindValue(':doctor', $doctor, PDO::PARAM_STR);
			$stmt->execute();
			return ;
		}

		public function removeCountryFromTreatmentAction(){
			$treatment = $this->_params['treatment'];
			$country = $this->_params['country'];
			$stmt = $this->db->prepare("DELETE FROM treatment_country WHERE treatmentID = :treatment AND countryID = :country");
			$stmt->bindValue(':treatment', $treatment, PDO::PARAM_STR);
			$stmt->bindValue(':country', $country, PDO::PARAM_STR);
			$stmt->execute();
			return ;
		}

		public function removeDoctorFromTreatmentAction(){
			$treatment = $this->_params['treatment'];
			$doctor = $this->_params['doctor'];
			$stmt = $this->db->prepare("DELETE FROM treatment_doctor WHERE treatmentID = :treatment AND doctorID = :doctor");
			$stmt->bindValue(':treatment', $treatment, PDO::PARAM_STR);
			$stmt->bindValue(':doctor', $doctor, PDO::PARAM_STR);
			$stmt->execute();
			return ;
		}		

		public function filterVerticalByTypeAction(){
			$type = $this->_params['type'];
			$stmt = $this->db->prepare("SELECT distinct t.name, t.description, t.token, t.status FROM treatments as t INNER JOIN treatment_doctor as td ON td.treatmentID = t.token INNER JOIN doctors as d ON d.token = td.doctorID WHERE t.status = 1 AND d.type = :type");
			$stmt->bindValue(':type', $type, PDO::PARAM_INT);
			$stmt->execute();
			$rows['verticals'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
			return $rows;
		}

	}
?>