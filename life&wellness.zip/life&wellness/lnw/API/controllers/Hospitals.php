<?php
	class Hospitals{
		private $db;
		private $_params;
		public function __construct($params){
			try{
				require_once '../../lnw/services/db_config.php';
				$this->db = new PDO ("mysql:host=$hostname;port=3306;dbname=$dbname","$username","$pw");
				$this->_params = $params;
			} catch (PDOException $e) {
				echo "Failed to get DB handle: " . $e->getMessage() . "\n";
				exit;
			}
		}

		public function getAction(){
			$token = $this->_params['token'];
			$stmt = $this->db->prepare("SELECT  h.id, h.name as name, h.token as token, h.street_address as address, state.token as stateID, state.name as state, country.token as countryID, country.name as country, h.status FROM hospitals as h INNER JOIN states as state ON state.token = h.stateID INNER JOIN countries as country ON country.token = h.countryID WHERE h.token = :token");
			$stmt->bindValue(':token', $token, PDO::PARAM_INT);
			$stmt->execute();
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			return $row;	
		}

		public function listAction(){
			$stmt = $this->db->prepare("SELECT h.id, h.name as name, h.token as token, h.street_address as address, state.token as stateID, state.name as state, country.token as countryID, country.name as country FROM hospitals as h INNER JOIN states as state ON state.token = h.stateID INNER JOIN countries as country ON country.token = h.countryID ORDER BY h.name");
			$stmt->execute();
			$row = $stmt->fetchAll(PDO::FETCH_ASSOC);
			return $row;
		}

		public function addAction(){
			$name = $this->_params['name'];
			$address = $this->_params['address'];
			$state = $this->_params['stateID'];
			$country = $this->_params['countryID'];
			$stmt = $this->db->prepare("INSERT into hospitals(name, street_address, stateID, countryID) VALUES(:name, :address, :state, :country)");
			$stmt->bindValue(':name', $name, PDO::PARAM_STR);
			$stmt->bindValue(':address', $address, PDO::PARAM_STR);
			$stmt->bindValue(':state', $state, PDO::PARAM_STR);
			$stmt->bindValue(':country', $country, PDO::PARAM_STR);
			$stmt->execute();
			$lastID = $this->db->lastInsertId();
			$stmt = $this->db->prepare("UPDATE hospitals SET token = :token WHERE id = :id");
			$stmt->bindValue(':token', md5($lastID), PDO::PARAM_STR);
			$stmt->bindValue(':id', $lastID, PDO::PARAM_INT);
			$stmt->execute();
			return array('token' => md5($lastID));
		}

		public function updateAction(){
			$name = $this->_params['name'];
			$address = $this->_params['address'];
			$state = $this->_params['stateID'];
			$country = $this->_params['countryID'];
			$status = $this->_params['status'];
			$token = $this->_params['token'];
			$stmt = $this->db->prepare("UPDATE hospitals set name = :name, stateID = :state, countryID = :country, street_address = :address, status = :status WHERE token = :token");
			$stmt->bindValue(':name', $name, PDO::PARAM_STR);
			$stmt->bindValue(':state', $state, PDO::PARAM_STR);
			$stmt->bindValue(':country', $country, PDO::PARAM_STR);
			$stmt->bindValue(':address', $address, PDO::PARAM_STR);
			$stmt->bindValue(':status', $status, PDO::PARAM_INT);
			$stmt->bindValue(':token', $token, PDO::PARAM_STR);
			$stmt->execute();
			return ;
		}


	}
?>