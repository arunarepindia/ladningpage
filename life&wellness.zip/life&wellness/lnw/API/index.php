<?php 
	//Define our id-key pairs
	$applications = array(
		'APP001' => '28e336ac6c9423d946ba02d19c6a2632' //randomly generated app key 
	);
	
	try{
		$enc_request = $_REQUEST['enc_request'];
		$app_id = $_REQUEST['app_id'];
		//print_r($enc_request);
		if(!isset($applications[$app_id])){
			throw new Exception('Application does not exist.'.$app_id);
		}
		//decrypt the request
		$params = json_decode(trim(mcrypt_decrypt(MCRYPT_RIJNDAEL_256, $applications[$app_id], base64_decode($enc_request), MCRYPT_MODE_ECB)));
		//print_r($params);
		//check if the request is valid by checking if it's an array and looking for the controller and action
		if( $params == false || isset($params->controller) == false || isset($params->action) == false ) {
			throw new Exception('Request is not valid'.$params);
		}
		//cast it into an array
		$params = (array) $params;
		
		//get the controller
		$controller = ucFirst(strtolower($params['controller']));
		$action = strtolower($params['action']).'Action';
		//check if controller exists
		if(file_exists('controllers/'.$controller.'.php')){
			include_once 'controllers/'.$controller.'.php';
		} else{
			throw new Exception('Controller is invalid');
		}
		//create new instance of controller
		$controller = new $controller($params);
		if(method_exists($controller,$action) === false){
			throw new Exception('Action is invalid');
		}
		//execute action
		$result['data'] = $controller->$action();
		$result['success'] = true;
		//print_r($result);
	} catch(Exception $e){
		$result = array();
		$result['success'] = false;
		$result['errormsg'] = $e->getMessage();
	}
	echo json_encode($result);
	exit();
?>